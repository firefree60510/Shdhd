package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.QrDatabase
import com.example.data.QrHistoryEntity
import com.example.data.QrHistoryRepository
import com.example.data.SettingsDataStore
import com.example.model.PayloadBuildResult
import com.example.model.QrCategory
import com.example.model.QrCenterLogo
import com.example.model.QrDesignConfig
import com.example.model.QrFormState
import com.example.model.QrPayloadBuilder
import com.example.model.QrTemplate
import com.example.model.QrTemplateRegistry
import com.example.model.ThemeMode
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class QrMakerViewModel(application: Application) : AndroidViewModel(application) {

    private val database = QrDatabase.getInstance(application)
    private val repository = QrHistoryRepository(database.qrHistoryDao())
    private val settingsStore = SettingsDataStore(application)

    val themeMode: StateFlow<ThemeMode> = settingsStore.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val premiumUnlocked: StateFlow<Boolean> = settingsStore.premiumDesignsUnlockedFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val generatedHistory: StateFlow<List<QrHistoryEntity>> = repository.generatedHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scannedHistory: StateFlow<List<QrHistoryEntity>> = repository.scannedHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _formState = MutableStateFlow(QrFormState())
    val formState: StateFlow<QrFormState> = _formState.asStateFlow()

    private val _activePayload = MutableStateFlow("https://qrmaker.app")
    val activePayload: StateFlow<String> = _activePayload.asStateFlow()

    private val _activeTitle = MutableStateFlow("QR Maker Preview")
    val activeTitle: StateFlow<String> = _activeTitle.asStateFlow()

    private val _activeCategory = MutableStateFlow(QrCategory.URL)
    val activeCategory: StateFlow<QrCategory> = _activeCategory.asStateFlow()

    private val _hasGeneratedQr = MutableStateFlow(false)
    val hasGeneratedQr: StateFlow<Boolean> = _hasGeneratedQr.asStateFlow()

    private val _editingHistoryId = MutableStateFlow<Long?>(null)
    val editingHistoryId: StateFlow<Long?> = _editingHistoryId.asStateFlow()

    private val _designConfig = MutableStateFlow(QrDesignConfig())
    val designConfig: StateFlow<QrDesignConfig> = _designConfig.asStateFlow()

    private val _generatorError = MutableStateFlow<String?>(null)
    val generatorError: StateFlow<String?> = _generatorError.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    fun selectCategory(category: QrCategory) {
        _generatorError.value = null
        _formState.update { it.copy(category = category) }
    }

    fun updateForm(transform: (QrFormState) -> QrFormState) {
        _generatorError.value = null
        _formState.update(transform)
    }

    fun clearFormForNewEntry(category: QrCategory? = null) {
        val targetCategory = category ?: _formState.value.category
        _formState.value = QrFormState(category = targetCategory)
        _editingHistoryId.value = null
        _generatorError.value = null
        _hasGeneratedQr.value = false
    }

    fun generateQr(saveToHistory: Boolean = true, applyProStyle: Boolean = false): Boolean {
        return when (val result = QrPayloadBuilder.build(_formState.value)) {
            is PayloadBuildResult.Invalid -> {
                _generatorError.value = result.errorMessage
                false
            }
            is PayloadBuildResult.Valid -> {
                _generatorError.value = null
                _activePayload.value = result.payload
                _activeTitle.value = result.displayTitle
                _activeCategory.value = _formState.value.category
                _hasGeneratedQr.value = true

                if (applyProStyle) {
                    val proTemplate = QrTemplateRegistry.getById("gradient")
                    _designConfig.value = proTemplate.config
                }

                if (saveToHistory) {
                    viewModelScope.launch {
                        val savedId = repository.saveGeneratedQr(
                            title = result.displayTitle,
                            content = result.payload,
                            category = _formState.value.category,
                            designConfig = _designConfig.value,
                            existingId = _editingHistoryId.value
                        )
                        _editingHistoryId.value = savedId
                    }
                }
                true
            }
        }
    }

    fun applyTemplate(template: QrTemplate): Boolean {
        if (template.isPremium && !premiumUnlocked.value) {
            return false
        }
        _designConfig.update { current ->
            template.config.copy(
                customLogoUri = if (template.config.centerLogo == QrCenterLogo.CUSTOM_URI) current.customLogoUri else null
            )
        }
        return true
    }

    fun updateDesign(transform: (QrDesignConfig) -> QrDesignConfig) {
        _designConfig.update(transform)
    }

    fun unlockPremiumDesigns() {
        viewModelScope.launch {
            settingsStore.setPremiumDesignsUnlocked(true)
            _snackbarEvents.tryEmit("All Premium QR templates unlocked!")
        }
    }

    fun saveCurrentDesignToHistory() {
        val payload = _activePayload.value
        if (payload.isBlank()) {
            _snackbarEvents.tryEmit("Generate a QR code first before saving.")
            return
        }
        viewModelScope.launch {
            val savedId = repository.saveGeneratedQr(
                title = _activeTitle.value.ifBlank { _activeCategory.value.displayName },
                content = payload,
                category = _activeCategory.value,
                designConfig = _designConfig.value,
                existingId = _editingHistoryId.value
            )
            _editingHistoryId.value = savedId
            _snackbarEvents.tryEmit("Design saved to My QR Codes")
        }
    }

    fun reopenHistoryItem(item: QrHistoryEntity) {
        val category = runCatching { QrCategory.valueOf(item.categoryName) }
            .getOrDefault(detectCategoryFromPayload(item.content))
        val restoredDesign = repository.decodeDesign(item.designJson)

        _activePayload.value = item.content
        _activeTitle.value = item.title
        _activeCategory.value = category
        _designConfig.value = restoredDesign
        _editingHistoryId.value = if (item.isScanned) null else item.id
        _hasGeneratedQr.value = true
        _generatorError.value = null

        _formState.value = buildFormStateFromPayload(category, item.title, item.content)
    }

    fun decodeDesign(designJson: String): QrDesignConfig {
        return repository.decodeDesign(designJson)
    }

    fun recordScannedQr(content: String) {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return
        val category = detectCategoryFromPayload(trimmed)
        val title = buildReadableScanTitle(category, trimmed)
        viewModelScope.launch {
            repository.saveScannedQr(
                title = title,
                content = trimmed,
                detectedCategory = category
            )
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteById(id)
            if (_editingHistoryId.value == id) {
                _editingHistoryId.value = null
            }
            _snackbarEvents.tryEmit("Deleted from history")
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
            _editingHistoryId.value = null
            _snackbarEvents.tryEmit("All QR history cleared")
        }
    }

    fun clearHistoryByType(isScanned: Boolean) {
        viewModelScope.launch {
            repository.clearByType(isScanned)
            _snackbarEvents.tryEmit(if (isScanned) "Scan history cleared" else "Saved QR codes cleared")
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            settingsStore.setThemeMode(mode)
        }
    }

    fun notifyMessage(message: String) {
        _snackbarEvents.tryEmit(message)
    }

    fun detectCategoryFromPayload(payload: String): QrCategory {
        val lower = payload.lowercase()
        return when {
            lower.startsWith("upi://pay") -> QrCategory.UPI
            lower.startsWith("wifi:") -> QrCategory.WIFI
            lower.startsWith("begin:vcard") -> QrCategory.VCARD
            lower.startsWith("mailto:") -> QrCategory.EMAIL
            lower.startsWith("tel:") -> QrCategory.PHONE
            lower.startsWith("smsto:") || lower.startsWith("sms:") -> QrCategory.SMS
            lower.startsWith("geo:") -> QrCategory.LOCATION
            lower.contains("wa.me/") || lower.contains("whatsapp.com/") -> QrCategory.WHATSAPP
            lower.contains("instagram.com/") -> QrCategory.INSTAGRAM
            lower.contains("facebook.com/") || lower.contains("fb.com/") -> QrCategory.FACEBOOK
            lower.contains("youtube.com/") || lower.contains("youtu.be/") -> QrCategory.YOUTUBE
            lower.startsWith("http://") || lower.startsWith("https://") -> QrCategory.URL
            else -> QrCategory.TEXT
        }
    }

    private fun buildReadableScanTitle(category: QrCategory, payload: String): String {
        return when (category) {
            QrCategory.URL -> payload.removePrefix("https://").removePrefix("http://").take(40)
            QrCategory.WIFI -> {
                val ssid = Regex("S:([^;]+)").find(payload)?.groupValues?.getOrNull(1) ?: "Network"
                "Wi-Fi: $ssid"
            }
            QrCategory.VCARD -> {
                val fn = Regex("FN:([^\r\n]+)").find(payload)?.groupValues?.getOrNull(1) ?: "Contact"
                fn
            }
            else -> payload.take(40)
        }
    }

    private fun buildFormStateFromPayload(
        category: QrCategory,
        title: String,
        payload: String
    ): QrFormState {
        return when (category) {
            QrCategory.URL -> QrFormState(category = category, title = title, url = payload)
            QrCategory.TEXT, QrCategory.CUSTOM -> QrFormState(category = category, title = title, text = payload)
            QrCategory.PHONE -> QrFormState(category = category, title = title, phone = payload.removePrefix("tel:"))
            QrCategory.EMAIL -> QrFormState(
                category = category,
                title = title,
                emailAddress = payload.removePrefix("mailto:").substringBefore("?")
            )
            QrCategory.SMS -> {
                val rest = payload.removePrefix("smsto:").removePrefix("sms:")
                val parts = rest.split(":", limit = 2)
                QrFormState(
                    category = category,
                    title = title,
                    phone = parts.getOrElse(0) { "" },
                    message = parts.getOrElse(1) { "" }
                )
            }
            QrCategory.INSTAGRAM, QrCategory.FACEBOOK, QrCategory.YOUTUBE ->
                QrFormState(category = category, title = title, socialHandleOrUrl = payload)
            else -> QrFormState(category = QrCategory.CUSTOM, title = title, text = payload)
        }
    }
}
