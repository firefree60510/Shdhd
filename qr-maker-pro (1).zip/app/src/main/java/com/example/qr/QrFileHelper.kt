package com.example.qr

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class QrExportFormat(val extension: String, val mimeType: String, val compressFormat: Bitmap.CompressFormat) {
    PNG("png", "image/png", Bitmap.CompressFormat.PNG),
    JPG("jpg", "image/jpeg", Bitmap.CompressFormat.JPEG)
}

object QrFileHelper {

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    suspend fun saveToGallery(
        context: Context,
        bitmap: Bitmap,
        fileNamePrefix: String,
        format: QrExportFormat
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val safeName = fileNamePrefix
                .replace(Regex("[^A-Za-z0-9_-]"), "_")
                .take(28)
                .ifBlank { "qr_code" }
            val fileName = "${safeName}_${System.currentTimeMillis()}.${format.extension}"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, format.mimeType)
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/QR Maker")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Unable to create MediaStore entry")

                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(format.compressFormat, 96, out)
                } ?: error("Unable to open output stream")

                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                "Saved $fileName to Pictures/QR Maker"
            } else {
                @Suppress("DEPRECATION")
                val picturesDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "QR Maker"
                )
                if (!picturesDir.exists() && !picturesDir.mkdirs()) {
                    // Fallback to app-specific external files if legacy public storage isn't writable
                    val fallbackDir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "QR Maker")
                    fallbackDir.mkdirs()
                    val file = File(fallbackDir, fileName)
                    FileOutputStream(file).use { out ->
                        bitmap.compress(format.compressFormat, 96, out)
                    }
                    "Saved $fileName to app gallery folder"
                } else {
                    val file = File(picturesDir, fileName)
                    FileOutputStream(file).use { out ->
                        bitmap.compress(format.compressFormat, 96, out)
                    }
                    MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf(format.mimeType), null)
                    "Saved $fileName to Pictures/QR Maker"
                }
            }
        }
    }

    suspend fun shareQrBitmap(
        context: Context,
        bitmap: Bitmap,
        title: String,
        format: QrExportFormat = QrExportFormat.PNG
    ): Result<Intent> = withContext(Dispatchers.IO) {
        runCatching {
            val sharedDir = File(context.cacheDir, "shared_qr").apply { mkdirs() }
            // Keep cache tidy by deleting old cached share files
            sharedDir.listFiles()?.forEach { old ->
                if (System.currentTimeMillis() - old.lastModified() > 60_000L) old.delete()
            }
            val file = File(sharedDir, "qr_maker_share_${System.currentTimeMillis()}.${format.extension}")
            FileOutputStream(file).use { out ->
                bitmap.compress(format.compressFormat, 96, out)
            }
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = format.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "QR Code generated with QR Maker: $title")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            Intent.createChooser(shareIntent, "Share QR Code")
        }
    }
}
