package com.example.qr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.model.QrCenterLogo
import com.example.model.QrCornerPattern
import com.example.model.QrDesignConfig
import com.example.model.QrDotPattern
import kotlin.math.min

object QrBitmapRenderer {

    fun render(
        context: Context,
        matrix: QrMatrix,
        config: QrDesignConfig,
        outputSizePx: Int = 720
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(outputSizePx, outputSizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bgColor = config.backgroundColorArgb.toInt()
        canvas.drawColor(bgColor)

        val quietZone = config.quietZoneModules.coerceIn(4, 8)
        val totalModules = matrix.size + quietZone * 2
        val moduleSize = outputSizePx.toFloat() / totalModules.toFloat()
        val offset = quietZone * moduleSize

        val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            if (config.useGradient) {
                shader = LinearGradient(
                    0f,
                    0f,
                    outputSizePx.toFloat(),
                    outputSizePx.toFloat(),
                    config.foregroundColorArgb.toInt(),
                    config.gradientEndColorArgb.toInt(),
                    Shader.TileMode.CLAMP
                )
            } else {
                color = config.foregroundColorArgb.toInt()
            }
        }

        val hasCenterLogo = config.centerLogo != QrCenterLogo.NONE &&
            (config.centerLogo != QrCenterLogo.CUSTOM_URI || !config.customLogoUri.isNullOrBlank())
        val logoRatio = config.logoSizeRatio.coerceIn(0.14f, 0.22f)
        val centerCutoutModules = if (hasCenterLogo) {
            (matrix.size * logoRatio).toInt().coerceAtLeast(3)
        } else {
            0
        }
        val centerMin = (matrix.size - centerCutoutModules) / 2f
        val centerMax = (matrix.size + centerCutoutModules) / 2f

        // 1. Draw data modules (excluding 3 finder zones and optional center logo zone)
        for (y in 0 until matrix.size) {
            for (x in 0 until matrix.size) {
                if (!matrix.get(x, y)) continue
                if (isInFinderPattern(x, y, matrix.size)) continue
                if (hasCenterLogo && x + 0.5f in centerMin..centerMax && y + 0.5f in centerMin..centerMax) {
                    continue
                }

                val left = offset + x * moduleSize
                val top = offset + y * moduleSize
                drawModule(canvas, left, top, moduleSize, config.dotPattern, fgPaint)
            }
        }

        // 2. Draw 3 finder patterns (Top-Left, Top-Right, Bottom-Left)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = bgColor
        }
        drawFinderEye(canvas, offset, offset, moduleSize, config.cornerPattern, fgPaint, bgPaint)
        drawFinderEye(
            canvas,
            offset + (matrix.size - 7) * moduleSize,
            offset,
            moduleSize,
            config.cornerPattern,
            fgPaint,
            bgPaint
        )
        drawFinderEye(
            canvas,
            offset,
            offset + (matrix.size - 7) * moduleSize,
            moduleSize,
            config.cornerPattern,
            fgPaint,
            bgPaint
        )

        // 3. Draw center logo if enabled
        if (hasCenterLogo) {
            val badgeSize = outputSizePx * logoRatio
            val center = outputSizePx / 2f
            val badgeRect = RectF(
                center - badgeSize / 2f,
                center - badgeSize / 2f,
                center + badgeSize / 2f,
                center + badgeSize / 2f
            )
            val cornerRadius = badgeSize * 0.24f

            // Protective background pad around logo for clean scannability
            val padPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = bgColor
                style = Paint.Style.FILL
            }
            val outerPad = badgeSize * 0.14f
            val padRect = RectF(
                badgeRect.left - outerPad,
                badgeRect.top - outerPad,
                badgeRect.right + outerPad,
                badgeRect.bottom + outerPad
            )
            canvas.drawRoundRect(padRect, cornerRadius + outerPad * 0.5f, cornerRadius + outerPad * 0.5f, padPaint)

            if (config.centerLogo == QrCenterLogo.CUSTOM_URI && !config.customLogoUri.isNullOrBlank()) {
                drawCustomLogoBitmap(context, canvas, config.customLogoUri, badgeRect, cornerRadius, fgPaint)
            } else {
                drawBuiltInCenterBadge(canvas, config, badgeRect, cornerRadius, fgPaint)
            }
        }

        return bitmap
    }

    private fun isInFinderPattern(x: Int, y: Int, size: Int): Boolean {
        val inTopLeft = x < 7 && y < 7
        val inTopRight = x >= size - 7 && y < 7
        val inBottomLeft = x < 7 && y >= size - 7
        return inTopLeft || inTopRight || inBottomLeft
    }

    private fun drawModule(
        canvas: Canvas,
        left: Float,
        top: Float,
        size: Float,
        pattern: QrDotPattern,
        paint: Paint
    ) {
        when (pattern) {
            QrDotPattern.SQUARE -> {
                // Slight 0.5px overlap prevents hairline anti-aliasing seams on low-end screens
                canvas.drawRect(left, top, left + size + 0.4f, top + size + 0.4f, paint)
            }
            QrDotPattern.ROUNDED -> {
                val inset = size * 0.06f
                val r = size * 0.30f
                canvas.drawRoundRect(
                    left + inset,
                    top + inset,
                    left + size - inset,
                    top + size - inset,
                    r,
                    r,
                    paint
                )
            }
            QrDotPattern.DOTS -> {
                val cx = left + size / 2f
                val cy = top + size / 2f
                canvas.drawCircle(cx, cy, size * 0.42f, paint)
            }
            QrDotPattern.PIXEL -> {
                val inset = size * 0.11f
                canvas.drawRect(
                    left + inset,
                    top + inset,
                    left + size - inset,
                    top + size - inset,
                    paint
                )
            }
            QrDotPattern.DIAMOND -> {
                val cx = left + size / 2f
                val cy = top + size / 2f
                val half = size * 0.47f
                val path = Path().apply {
                    moveTo(cx, cy - half)
                    lineTo(cx + half, cy)
                    lineTo(cx, cy + half)
                    lineTo(cx - half, cy)
                    close()
                }
                canvas.drawPath(path, paint)
            }
            QrDotPattern.VERTICAL_BARS -> {
                val insetX = size * 0.14f
                val r = size * 0.25f
                canvas.drawRoundRect(
                    left + insetX,
                    top,
                    left + size - insetX,
                    top + size + 0.4f,
                    r,
                    r,
                    paint
                )
            }
        }
    }

    private fun drawFinderEye(
        canvas: Canvas,
        left: Float,
        top: Float,
        moduleSize: Float,
        pattern: QrCornerPattern,
        fgPaint: Paint,
        bgPaint: Paint
    ) {
        val outerSize = 7f * moduleSize
        val innerCutSize = 5f * moduleSize
        val coreSize = 3f * moduleSize

        val outerRect = RectF(left, top, left + outerSize, top + outerSize)
        val innerCutRect = RectF(
            left + moduleSize,
            top + moduleSize,
            left + outerSize - moduleSize,
            top + outerSize - moduleSize
        )
        val coreRect = RectF(
            left + 2f * moduleSize,
            top + 2f * moduleSize,
            left + outerSize - 2f * moduleSize,
            top + outerSize - 2f * moduleSize
        )

        when (pattern) {
            QrCornerPattern.SQUARE -> {
                canvas.drawRect(outerRect, fgPaint)
                canvas.drawRect(innerCutRect, bgPaint)
                canvas.drawRect(coreRect, fgPaint)
            }
            QrCornerPattern.ROUNDED -> {
                canvas.drawRoundRect(outerRect, moduleSize * 1.6f, moduleSize * 1.6f, fgPaint)
                canvas.drawRoundRect(innerCutRect, moduleSize * 1.1f, moduleSize * 1.1f, bgPaint)
                canvas.drawRoundRect(coreRect, moduleSize * 0.8f, moduleSize * 0.8f, fgPaint)
            }
            QrCornerPattern.EXTRA_ROUNDED -> {
                canvas.drawRoundRect(outerRect, moduleSize * 2.4f, moduleSize * 2.4f, fgPaint)
                canvas.drawRoundRect(innerCutRect, moduleSize * 1.7f, moduleSize * 1.7f, bgPaint)
                canvas.drawRoundRect(coreRect, moduleSize * 1.1f, moduleSize * 1.1f, fgPaint)
            }
            QrCornerPattern.CIRCLE -> {
                val cx = left + outerSize / 2f
                val cy = top + outerSize / 2f
                canvas.drawCircle(cx, cy, outerSize / 2f, fgPaint)
                canvas.drawCircle(cx, cy, innerCutSize / 2f, bgPaint)
                canvas.drawCircle(cx, cy, coreSize / 2f, fgPaint)
            }
            QrCornerPattern.LEAF -> {
                val r = moduleSize * 2.6f
                val rInner = moduleSize * 1.8f
                val rCore = moduleSize * 1.1f
                drawLeafRect(canvas, outerRect, r, fgPaint)
                drawLeafRect(canvas, innerCutRect, rInner, bgPaint)
                drawLeafRect(canvas, coreRect, rCore, fgPaint)
            }
        }
    }

    private fun drawLeafRect(canvas: Canvas, rect: RectF, radius: Float, paint: Paint) {
        val radii = floatArrayOf(
            radius, radius,   // top-left rounded
            0f, 0f,           // top-right sharp
            radius, radius,   // bottom-right rounded
            0f, 0f            // bottom-left sharp
        )
        val path = Path().apply {
            addRoundRect(rect, radii, Path.Direction.CW)
        }
        canvas.drawPath(path, paint)
    }

    private fun drawCustomLogoBitmap(
        context: Context,
        canvas: Canvas,
        uriString: String,
        badgeRect: RectF,
        cornerRadius: Float,
        fallbackPaint: Paint
    ) {
        val loaded = runCatching {
            val uri = Uri.parse(uriString)
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(stream, null, options)
                val maxDim = maxOf(options.outWidth, options.outHeight).coerceAtLeast(1)
                val sampleSize = (maxDim / 256).coerceAtLeast(1)
                context.contentResolver.openInputStream(uri)?.use { decodeStream ->
                    BitmapFactory.decodeStream(
                        decodeStream,
                        null,
                        BitmapFactory.Options().apply { inSampleSize = sampleSize }
                    )
                }
            }
        }.getOrNull()

        if (loaded != null) {
            val clipPath = Path().apply {
                addRoundRect(badgeRect, cornerRadius, cornerRadius, Path.Direction.CW)
            }
            canvas.save()
            canvas.clipPath(clipPath)
            val srcSize = min(loaded.width, loaded.height)
            val srcLeft = (loaded.width - srcSize) / 2
            val srcTop = (loaded.height - srcSize) / 2
            val srcRect = android.graphics.Rect(srcLeft, srcTop, srcLeft + srcSize, srcTop + srcSize)
            canvas.drawBitmap(loaded, srcRect, badgeRect, Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
            if (!loaded.isRecycled) loaded.recycle()
        } else {
            canvas.drawRoundRect(badgeRect, cornerRadius, cornerRadius, fallbackPaint)
        }
    }

    private fun drawBuiltInCenterBadge(
        canvas: Canvas,
        config: QrDesignConfig,
        badgeRect: RectF,
        cornerRadius: Float,
        fgPaint: Paint
    ) {
        canvas.drawRoundRect(badgeRect, cornerRadius, cornerRadius, fgPaint)

        val fgColor = config.foregroundColorArgb.toInt()
        val lum = (0.299 * Color.red(fgColor) + 0.587 * Color.green(fgColor) + 0.114 * Color.blue(fgColor)) / 255.0
        val glyphColor = if (lum > 0.65) Color.parseColor("#0F172A") else Color.WHITE

        val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = glyphColor
            style = Paint.Style.STROKE
            strokeWidth = badgeRect.width() * 0.09f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val fillGlyphPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = glyphColor
            style = Paint.Style.FILL
            textAlign = Paint.Align.CENTER
            textSize = badgeRect.height() * 0.48f
            isFakeBoldText = true
        }

        val cx = badgeRect.centerX()
        val cy = badgeRect.centerY()
        val r = badgeRect.width() * 0.28f

        when (config.centerLogo) {
            QrCenterLogo.SPARKLE -> {
                val path = Path().apply {
                    moveTo(cx, cy - r * 1.15f)
                    quadTo(cx, cy, cx + r * 1.15f, cy)
                    quadTo(cx, cy, cx, cy + r * 1.15f)
                    quadTo(cx, cy, cx - r * 1.15f, cy)
                    quadTo(cx, cy, cx, cy - r * 1.15f)
                    close()
                }
                canvas.drawPath(path, fillGlyphPaint)
            }
            QrCenterLogo.GLOBE -> {
                canvas.drawCircle(cx, cy, r, glyphPaint)
                canvas.drawOval(RectF(cx - r * 0.5f, cy - r, cx + r * 0.5f, cy + r), glyphPaint)
                canvas.drawLine(cx - r, cy, cx + r, cy, glyphPaint)
            }
            QrCenterLogo.WIFI -> {
                canvas.drawArc(RectF(cx - r, cy - r * 0.6f, cx + r, cy + r * 1.4f), 225f, 90f, false, glyphPaint)
                canvas.drawArc(RectF(cx - r * 0.6f, cy - r * 0.2f, cx + r * 0.6f, cy + r), 225f, 90f, false, glyphPaint)
                canvas.drawCircle(cx, cy + r * 0.55f, r * 0.16f, fillGlyphPaint)
            }
            QrCenterLogo.PLAY -> {
                val path = Path().apply {
                    moveTo(cx - r * 0.55f, cy - r * 0.75f)
                    lineTo(cx + r * 0.85f, cy)
                    lineTo(cx - r * 0.55f, cy + r * 0.75f)
                    close()
                }
                canvas.drawPath(path, fillGlyphPaint)
            }
            QrCenterLogo.PAYMENT -> {
                val baseline = cy - (fillGlyphPaint.descent() + fillGlyphPaint.ascent()) / 2f
                canvas.drawText("₹", cx, baseline, fillGlyphPaint)
            }
            QrCenterLogo.EMAIL -> {
                val env = RectF(cx - r, cy - r * 0.7f, cx + r, cy + r * 0.7f)
                canvas.drawRoundRect(env, r * 0.18f, r * 0.18f, glyphPaint)
                val flap = Path().apply {
                    moveTo(env.left, env.top + r * 0.1f)
                    lineTo(cx, cy + r * 0.1f)
                    lineTo(env.right, env.top + r * 0.1f)
                }
                canvas.drawPath(flap, glyphPaint)
            }
            QrCenterLogo.LOCATION -> {
                canvas.drawCircle(cx, cy - r * 0.2f, r * 0.55f, glyphPaint)
                canvas.drawCircle(cx, cy - r * 0.2f, r * 0.18f, fillGlyphPaint)
                val tip = Path().apply {
                    moveTo(cx - r * 0.48f, cy + r * 0.05f)
                    lineTo(cx, cy + r * 0.95f)
                    lineTo(cx + r * 0.48f, cy + r * 0.05f)
                }
                canvas.drawPath(tip, glyphPaint)
            }
            QrCenterLogo.CAMERA -> {
                val cam = RectF(cx - r, cy - r * 0.7f, cx + r, cy + r * 0.7f)
                canvas.drawRoundRect(cam, r * 0.35f, r * 0.35f, glyphPaint)
                canvas.drawCircle(cx, cy, r * 0.35f, glyphPaint)
            }
            QrCenterLogo.CHAT -> {
                val bubble = RectF(cx - r, cy - r * 0.75f, cx + r, cy + r * 0.55f)
                canvas.drawRoundRect(bubble, r * 0.45f, r * 0.45f, glyphPaint)
                canvas.drawLine(cx - r * 0.45f, cy + r * 0.55f, cx - r * 0.75f, cy + r * 0.95f, glyphPaint)
            }
            QrCenterLogo.PHONE -> {
                val phoneRect = RectF(cx - r * 0.58f, cy - r, cx + r * 0.58f, cy + r)
                canvas.drawRoundRect(phoneRect, r * 0.25f, r * 0.25f, glyphPaint)
                canvas.drawCircle(cx, cy + r * 0.65f, r * 0.1f, fillGlyphPaint)
            }
            QrCenterLogo.CONTACT -> {
                canvas.drawCircle(cx, cy - r * 0.35f, r * 0.38f, glyphPaint)
                canvas.drawArc(RectF(cx - r * 0.85f, cy + r * 0.15f, cx + r * 0.85f, cy + r * 1.25f), 180f, 180f, false, glyphPaint)
            }
            QrCenterLogo.NONE, QrCenterLogo.CUSTOM_URI -> Unit
        }
    }

    fun iconForLogo(logo: QrCenterLogo): ImageVector {
        return when (logo) {
            QrCenterLogo.NONE -> Icons.Rounded.AutoAwesome
            QrCenterLogo.GLOBE -> Icons.Rounded.Language
            QrCenterLogo.PHONE -> Icons.Rounded.Call
            QrCenterLogo.CHAT -> Icons.Rounded.Chat
            QrCenterLogo.EMAIL -> Icons.Rounded.AlternateEmail
            QrCenterLogo.WIFI -> Icons.Rounded.Wifi
            QrCenterLogo.CONTACT -> Icons.Rounded.Contacts
            QrCenterLogo.LOCATION -> Icons.Rounded.LocationOn
            QrCenterLogo.PAYMENT -> Icons.Rounded.AccountBalanceWallet
            QrCenterLogo.CAMERA -> Icons.Rounded.CameraAlt
            QrCenterLogo.PLAY -> Icons.Rounded.PlayArrow
            QrCenterLogo.SPARKLE -> Icons.Rounded.AutoAwesome
            QrCenterLogo.CUSTOM_URI -> Icons.Rounded.CameraAlt
        }
    }
}
