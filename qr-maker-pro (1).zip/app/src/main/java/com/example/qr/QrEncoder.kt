package com.example.qr

import android.graphics.Color
import com.example.model.QrDesignConfig
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

data class QrMatrix(
    val size: Int,
    val modules: BooleanArray
) {
    fun get(x: Int, y: Int): Boolean {
        if (x !in 0 until size || y !in 0 until size) return false
        return modules[y * size + x]
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is QrMatrix) return false
        return size == other.size && modules.contentEquals(other.modules)
    }

    override fun hashCode(): Int {
        var result = size
        result = 31 * result + modules.contentHashCode()
        return result
    }
}

data class ContrastEvaluation(
    val ratio: Float,
    val isScannable: Boolean,
    val isInverted: Boolean,
    val statusText: String
)

object QrEncoder {
    fun encode(content: String, highErrorCorrection: Boolean = true): QrMatrix? {
        if (content.isBlank()) return null
        return runCatching {
            val hints = mapOf(
                EncodeHintType.CHARACTER_SET to "UTF-8"
            )
            val ecLevel = if (highErrorCorrection) ErrorCorrectionLevel.H else ErrorCorrectionLevel.M
            val qrCode = Encoder.encode(content, ecLevel, hints)
            val byteMatrix = qrCode.matrix
            val width = byteMatrix.width
            val height = byteMatrix.height
            val size = max(width, height)
            val modules = BooleanArray(size * size)
            for (y in 0 until height) {
                for (x in 0 until width) {
                    modules[y * size + x] = byteMatrix.get(x, y).toInt() != 0
                }
            }
            QrMatrix(size = size, modules = modules)
        }.getOrNull()
    }

    fun evaluateContrast(config: QrDesignConfig): ContrastEvaluation {
        val fgColor = config.foregroundColorArgb.toInt()
        val bgColor = config.backgroundColorArgb.toInt()
        val fgLum = relativeLuminance(fgColor)
        val bgLum = relativeLuminance(bgColor)
        val ratioFg = contrastRatio(fgLum, bgLum)

        val effectiveRatio = if (config.useGradient) {
            val gradLum = relativeLuminance(config.gradientEndColorArgb.toInt())
            min(ratioFg, contrastRatio(gradLum, bgLum))
        } else {
            ratioFg
        }

        val isInverted = fgLum > bgLum
        val isScannable = effectiveRatio >= 3.0f

        val statusText = when {
            effectiveRatio < 2.2f -> "Low contrast (${formatRatio(effectiveRatio)}) — may fail to scan"
            effectiveRatio < 3.0f -> "Moderate contrast (${formatRatio(effectiveRatio)}) — increase separation"
            isInverted -> "High contrast inverted (${formatRatio(effectiveRatio)})"
            effectiveRatio >= 7.0f -> "Optimal contrast (${formatRatio(effectiveRatio)}) • Ultra scannable"
            else -> "Good contrast (${formatRatio(effectiveRatio)}) • Scannable"
        }

        return ContrastEvaluation(
            ratio = effectiveRatio,
            isScannable = isScannable,
            isInverted = isInverted,
            statusText = statusText
        )
    }

    private fun contrastRatio(lum1: Double, lum2: Double): Float {
        val lighter = max(lum1, lum2)
        val darker = min(lum1, lum2)
        return ((lighter + 0.05) / (darker + 0.05)).toFloat()
    }

    private fun relativeLuminance(argb: Int): Double {
        val r = linearize(Color.red(argb) / 255.0)
        val g = linearize(Color.green(argb) / 255.0)
        val b = linearize(Color.blue(argb) / 255.0)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    private fun linearize(channel: Double): Double {
        return if (channel <= 0.03928) channel / 12.92 else ((channel + 0.055) / 1.055).pow(2.4)
    }

    private fun formatRatio(ratio: Float): String {
        val rounded = (ratio * 10).toInt() / 10f
        return "${rounded}:1"
    }
}
