package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ads.AdManager
import com.example.model.QrCategory
import com.example.model.ThemeMode
import com.example.ui.components.SplashOverlay
import com.example.ui.navigation.GeneratorRoute
import com.example.ui.navigation.HistoryRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.ScannerRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.navigation.StudioRoute
import com.example.ui.screens.DesignStudioScreen
import com.example.ui.screens.GeneratorScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.QrMakerTheme
import com.example.viewmodel.QrMakerViewModel

private data class TopNavItem<T : Any>(
    val route: T,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AdManager.initialize(this)

        setContent {
            val viewModel: QrMakerViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            val useDarkTheme = when (themeMode) {
                ThemeMode.SYSTEM -> systemDark
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            QrMakerTheme(darkTheme = useDarkTheme) {
                QrMakerAppShell(viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun QrMakerAppShell(viewModel: QrMakerViewModel) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    var showSplash by rememberSaveable { mutableStateOf(true) }

    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val premiumUnlocked by viewModel.premiumUnlocked.collectAsStateWithLifecycle()
    val generatedHistory by viewModel.generatedHistory.collectAsStateWithLifecycle()
    val scannedHistory by viewModel.scannedHistory.collectAsStateWithLifecycle()
    val formState by viewModel.formState.collectAsStateWithLifecycle()
    val activePayload by viewModel.activePayload.collectAsStateWithLifecycle()
    val activeTitle by viewModel.activeTitle.collectAsStateWithLifecycle()
    val hasGeneratedQr by viewModel.hasGeneratedQr.collectAsStateWithLifecycle()
    val designConfig by viewModel.designConfig.collectAsStateWithLifecycle()
    val generatorError by viewModel.generatorError.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val navItems = remember {
        listOf(
            TopNavItem(HomeRoute, "Home", Icons.Rounded.Home, Icons.Outlined.Home, "nav_home"),
            TopNavItem(GeneratorRoute(), "Create", Icons.Rounded.QrCode2, Icons.Outlined.QrCode2, "nav_create"),
            TopNavItem(StudioRoute, "Studio", Icons.Rounded.Palette, Icons.Outlined.Palette, "nav_studio"),
            TopNavItem(ScannerRoute, "Scan", Icons.Rounded.QrCodeScanner, Icons.Outlined.QrCodeScanner, "nav_scan"),
            TopNavItem(HistoryRoute(), "History", Icons.Rounded.History, Icons.Outlined.History, "nav_history")
        )
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val isSettingsRoute = currentDestination?.hasRoute<SettingsRoute>() == true

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavRail = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useNavRail && !isSettingsRoute) {
                        NavigationBar {
                            navItems.forEach { item ->
                                val selected = currentDestination?.hasRoute(item.route::class) == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    },
                                    label = { Text(item.label) },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavRail && !isSettingsRoute) {
                        NavigationRail(
                            modifier = Modifier
                                .fillMaxHeight()
                                .windowInsetsPadding(WindowInsets.safeDrawing)
                        ) {
                            Spacer(modifier = Modifier.weight(0.1f))
                            navItems.forEach { item ->
                                val selected = currentDestination?.hasRoute(item.route::class) == true
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    },
                                    label = { Text(item.label) },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = HomeRoute,
                        modifier = Modifier.weight(1f).fillMaxSize()
                    ) {
                        composable<HomeRoute> {
                            HomeScreen(
                                generatedCount = generatedHistory.size,
                                scannedCount = scannedHistory.size,
                                onOpenGenerator = { category ->
                                    if (category != null) {
                                        viewModel.selectCategory(category)
                                    }
                                    navigateTopLevel(GeneratorRoute(category?.name))
                                },
                                onOpenMyQrCodes = {
                                    navigateTopLevel(HistoryRoute(initialTab = 0))
                                },
                                onOpenScanner = {
                                    navigateTopLevel(ScannerRoute)
                                },
                                onOpenStudio = {
                                    navigateTopLevel(StudioRoute)
                                },
                                onOpenHistory = {
                                    navigateTopLevel(HistoryRoute(initialTab = 1))
                                },
                                onOpenSettings = {
                                    navController.navigate(SettingsRoute)
                                }
                            )
                        }

                        composable<GeneratorRoute> { entry ->
                            val route = entry.toRoute<GeneratorRoute>()
                            LaunchedEffect(route.categoryName) {
                                route.categoryName?.let { name ->
                                    runCatching { QrCategory.valueOf(name) }
                                        .getOrNull()
                                        ?.let { viewModel.selectCategory(it) }
                                }
                            }
                            GeneratorScreen(
                                formState = formState,
                                activePayload = activePayload,
                                activeTitle = activeTitle,
                                hasGeneratedQr = hasGeneratedQr,
                                designConfig = designConfig,
                                errorMessage = generatorError,
                                onSelectCategory = viewModel::selectCategory,
                                onUpdateForm = viewModel::updateForm,
                                onClearForm = { viewModel.clearFormForNewEntry() },
                                onGenerateQr = { applyPro -> viewModel.generateQr(saveToHistory = true, applyProStyle = applyPro) },
                                onOpenDesignStudio = { navigateTopLevel(StudioRoute) },
                                onSaveToHistory = viewModel::saveCurrentDesignToHistory,
                                onStatusMessage = viewModel::notifyMessage
                            )
                        }

                        composable<StudioRoute> {
                            DesignStudioScreen(
                                payload = activePayload,
                                title = activeTitle,
                                designConfig = designConfig,
                                premiumUnlocked = premiumUnlocked,
                                onApplyTemplate = viewModel::applyTemplate,
                                onUpdateDesign = viewModel::updateDesign,
                                onUnlockPremium = viewModel::unlockPremiumDesigns,
                                onSaveToHistory = viewModel::saveCurrentDesignToHistory,
                                onStatusMessage = viewModel::notifyMessage
                            )
                        }

                        composable<ScannerRoute> {
                            ScannerScreen(
                                detectCategory = viewModel::detectCategoryFromPayload,
                                onQrScanned = viewModel::recordScannedQr,
                                onStatusMessage = viewModel::notifyMessage
                            )
                        }

                        composable<HistoryRoute> { entry ->
                            val route = entry.toRoute<HistoryRoute>()
                            HistoryScreen(
                                initialTab = route.initialTab,
                                generatedHistory = generatedHistory,
                                scannedHistory = scannedHistory,
                                decodeDesign = viewModel::decodeDesign,
                                onReopenAndEdit = { item ->
                                    viewModel.reopenHistoryItem(item)
                                    navigateTopLevel(StudioRoute)
                                },
                                onDeleteItem = viewModel::deleteHistoryItem,
                                onClearTabHistory = viewModel::clearHistoryByType,
                                onStatusMessage = viewModel::notifyMessage
                            )
                        }

                        composable<SettingsRoute> {
                            SettingsScreen(
                                themeMode = themeMode,
                                onSetThemeMode = viewModel::setThemeMode,
                                onClearAllHistory = viewModel::clearAllHistory,
                                onBack = { navController.popBackStack() },
                                onStatusMessage = viewModel::notifyMessage
                            )
                        }
                    }
                }
            }
        }

        SplashOverlay(
            visible = showSplash,
            onFinished = { showSplash = false }
        )
    }
}
