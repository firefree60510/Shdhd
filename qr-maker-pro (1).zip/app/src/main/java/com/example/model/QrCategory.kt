package com.example.model

import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class QrCategory(
    val displayName: String,
    val shortLabel: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color
) {
    URL("Website URL", "URL", "Links & landing pages", Icons.Rounded.Language, Color(0xFF4F46E5)),
    TEXT("Plain Text", "Text", "Notes, codes & messages", Icons.Rounded.TextFields, Color(0xFF2563EB)),
    PHONE("Phone Number", "Phone", "One-tap dial link", Icons.Rounded.Call, Color(0xFF0EA5E9)),
    WHATSAPP("WhatsApp", "WhatsApp", "Direct chat & message", Icons.Rounded.Chat, Color(0xFF10B981)),
    EMAIL("Email", "Email", "Recipient, subject & body", Icons.Rounded.AlternateEmail, Color(0xFF7C3AED)),
    SMS("SMS", "SMS", "Text message shortcut", Icons.Rounded.Sms, Color(0xFF6366F1)),
    WIFI("Wi-Fi", "Wi-Fi", "Auto-join wireless network", Icons.Rounded.Wifi, Color(0xFF0284C7)),
    VCARD("Contact / vCard", "Contact", "Digital business card", Icons.Rounded.Contacts, Color(0xFF8B5CF6)),
    LOCATION("Location", "Location", "GPS coordinates & maps", Icons.Rounded.LocationOn, Color(0xFFEF4444)),
    UPI("UPI Payment", "UPI Pay", "Instant payment QR", Icons.Rounded.AccountBalanceWallet, Color(0xFF059669)),
    INSTAGRAM("Instagram", "Instagram", "Profile or reel link", Icons.Rounded.CameraAlt, Color(0xFFE1306C)),
    FACEBOOK("Facebook", "Facebook", "Page or profile link", Icons.Rounded.Public, Color(0xFF1877F2)),
    YOUTUBE("YouTube", "YouTube", "Channel or video URL", Icons.Rounded.PlayCircle, Color(0xFFDC2626)),
    CUSTOM("Custom QR", "Custom", "Raw format or custom data", Icons.Rounded.QrCode2, Color(0xFF4338CA))
}

enum class WifiSecurity(val code: String, val label: String) {
    WPA("WPA", "WPA/WPA2"),
    WEP("WEP", "WEP"),
    NONE("nopass", "Open (No Password)")
}

data class QrFormState(
    val category: QrCategory = QrCategory.URL,
    val title: String = "",
    // URL
    val url: String = "",
    // Plain Text / Custom
    val text: String = "",
    // Phone / WhatsApp / SMS
    val phone: String = "",
    val message: String = "",
    // Email
    val emailAddress: String = "",
    val emailSubject: String = "",
    val emailBody: String = "",
    // Wi-Fi
    val wifiSsid: String = "",
    val wifiPassword: String = "",
    val wifiSecurity: WifiSecurity = WifiSecurity.WPA,
    val wifiHidden: Boolean = false,
    // vCard
    val firstName: String = "",
    val lastName: String = "",
    val organization: String = "",
    val jobTitle: String = "",
    val vcardPhone: String = "",
    val vcardEmail: String = "",
    val vcardWebsite: String = "",
    val vcardAddress: String = "",
    // Location
    val latitude: String = "",
    val longitude: String = "",
    val locationLabel: String = "",
    // UPI
    val upiId: String = "",
    val upiPayeeName: String = "",
    val upiAmount: String = "",
    val upiNote: String = "",
    // Social
    val socialHandleOrUrl: String = ""
)

sealed interface PayloadBuildResult {
    data class Valid(val payload: String, val displayTitle: String) : PayloadBuildResult
    data class Invalid(val errorMessage: String) : PayloadBuildResult
}

object QrPayloadBuilder {
    fun build(state: QrFormState): PayloadBuildResult {
        return when (state.category) {
            QrCategory.URL -> {
                val raw = state.url.trim()
                if (raw.isEmpty()) return PayloadBuildResult.Invalid("Please enter a website URL.")
                val normalized = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) {
                    raw
                } else {
                    "https://$raw"
                }
                if (!normalized.contains('.')) {
                    return PayloadBuildResult.Invalid("Enter a valid domain such as example.com.")
                }
                PayloadBuildResult.Valid(normalized, state.title.ifBlank { normalized.removePrefix("https://").removePrefix("http://") })
            }

            QrCategory.TEXT -> {
                val raw = state.text.trim()
                if (raw.isEmpty()) return PayloadBuildResult.Invalid("Please enter some text to encode.")
                PayloadBuildResult.Valid(raw, state.title.ifBlank { raw.take(36) })
            }

            QrCategory.PHONE -> {
                val clean = state.phone.trim().replace(" ", "")
                if (clean.length < 4) return PayloadBuildResult.Invalid("Please enter a valid phone number.")
                PayloadBuildResult.Valid("tel:$clean", state.title.ifBlank { "Call $clean" })
            }

            QrCategory.WHATSAPP -> {
                val digits = state.phone.trim().filter { it.isDigit() }
                if (digits.length < 6) return PayloadBuildResult.Invalid("Enter a WhatsApp number with country code (digits only, e.g. 15551234567).")
                val msg = state.message.trim()
                val payload = if (msg.isNotEmpty()) {
                    "https://wa.me/$digits?text=${Uri.encode(msg)}"
                } else {
                    "https://wa.me/$digits"
                }
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "WhatsApp +$digits" })
            }

            QrCategory.EMAIL -> {
                val addr = state.emailAddress.trim()
                if (addr.isEmpty() || !addr.contains('@') || !addr.contains('.')) {
                    return PayloadBuildResult.Invalid("Please enter a valid email address.")
                }
                val params = buildList {
                    if (state.emailSubject.isNotBlank()) add("subject=${Uri.encode(state.emailSubject.trim())}")
                    if (state.emailBody.isNotBlank()) add("body=${Uri.encode(state.emailBody.trim())}")
                }
                val payload = if (params.isEmpty()) "mailto:$addr" else "mailto:$addr?${params.joinToString("&")}"
                PayloadBuildResult.Valid(payload, state.title.ifBlank { addr })
            }

            QrCategory.SMS -> {
                val clean = state.phone.trim().replace(" ", "")
                if (clean.length < 4) return PayloadBuildResult.Invalid("Please enter a recipient phone number.")
                val body = state.message.trim()
                val payload = if (body.isNotEmpty()) "smsto:$clean:$body" else "smsto:$clean"
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "SMS to $clean" })
            }

            QrCategory.WIFI -> {
                val ssid = state.wifiSsid.trim()
                if (ssid.isEmpty()) return PayloadBuildResult.Invalid("Please enter the Wi-Fi network name (SSID).")
                if (state.wifiSecurity != WifiSecurity.NONE && state.wifiPassword.isEmpty()) {
                    return PayloadBuildResult.Invalid("Enter the Wi-Fi password or switch security to Open.")
                }
                val escSsid = escapeWifiField(ssid)
                val escPass = escapeWifiField(state.wifiPassword)
                val hiddenFlag = if (state.wifiHidden) "true" else "false"
                val payload = "WIFI:T:${state.wifiSecurity.code};S:$escSsid;P:$escPass;H:$hiddenFlag;;"
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "Wi-Fi: $ssid" })
            }

            QrCategory.VCARD -> {
                val first = state.firstName.trim()
                val last = state.lastName.trim()
                if (first.isEmpty() && last.isEmpty()) {
                    return PayloadBuildResult.Invalid("Please enter at least a first or last name.")
                }
                val fullName = listOf(first, last).filter { it.isNotEmpty() }.joinToString(" ")
                val lines = buildList {
                    add("BEGIN:VCARD")
                    add("VERSION:3.0")
                    add("N:$last;$first;;;")
                    add("FN:$fullName")
                    if (state.organization.isNotBlank()) add("ORG:${state.organization.trim()}")
                    if (state.jobTitle.isNotBlank()) add("TITLE:${state.jobTitle.trim()}")
                    if (state.vcardPhone.isNotBlank()) add("TEL;TYPE=CELL:${state.vcardPhone.trim()}")
                    if (state.vcardEmail.isNotBlank()) add("EMAIL:${state.vcardEmail.trim()}")
                    if (state.vcardWebsite.isNotBlank()) add("URL:${state.vcardWebsite.trim()}")
                    if (state.vcardAddress.isNotBlank()) add("ADR:;;${state.vcardAddress.trim()};;;;")
                    add("END:VCARD")
                }
                PayloadBuildResult.Valid(lines.joinToString("\n"), state.title.ifBlank { fullName })
            }

            QrCategory.LOCATION -> {
                val lat = state.latitude.trim().toDoubleOrNull()
                val lng = state.longitude.trim().toDoubleOrNull()
                if (lat == null || lat !in -90.0..90.0) {
                    return PayloadBuildResult.Invalid("Enter a valid latitude between -90 and 90.")
                }
                if (lng == null || lng !in -180.0..180.0) {
                    return PayloadBuildResult.Invalid("Enter a valid longitude between -180 and 180.")
                }
                val label = state.locationLabel.trim()
                val payload = if (label.isNotEmpty()) {
                    "geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})"
                } else {
                    "geo:$lat,$lng"
                }
                PayloadBuildResult.Valid(payload, state.title.ifBlank { label.ifBlank { "$lat, $lng" } })
            }

            QrCategory.UPI -> {
                val pa = state.upiId.trim()
                val pn = state.upiPayeeName.trim()
                if (pa.isEmpty() || !pa.contains('@')) {
                    return PayloadBuildResult.Invalid("Enter a valid UPI ID (e.g. name@bank).")
                }
                if (pn.isEmpty()) {
                    return PayloadBuildResult.Invalid("Enter the payee name.")
                }
                val amtStr = state.upiAmount.trim()
                if (amtStr.isNotEmpty()) {
                    val amt = amtStr.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        return PayloadBuildResult.Invalid("Enter a valid positive amount or leave blank.")
                    }
                }
                val params = buildList {
                    add("pa=${Uri.encode(pa)}")
                    add("pn=${Uri.encode(pn)}")
                    if (amtStr.isNotEmpty()) add("am=${Uri.encode(amtStr)}")
                    if (state.upiNote.isNotBlank()) add("tn=${Uri.encode(state.upiNote.trim())}")
                    add("cu=INR")
                }
                val payload = "upi://pay?${params.joinToString("&")}"
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "UPI: $pn" })
            }

            QrCategory.INSTAGRAM -> {
                val raw = state.socialHandleOrUrl.trim()
                if (raw.isEmpty()) return PayloadBuildResult.Invalid("Enter an Instagram username or profile URL.")
                val payload = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) {
                    raw
                } else {
                    "https://instagram.com/${raw.removePrefix("@")}"
                }
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "Instagram @${raw.removePrefix("@")}" })
            }

            QrCategory.FACEBOOK -> {
                val raw = state.socialHandleOrUrl.trim()
                if (raw.isEmpty()) return PayloadBuildResult.Invalid("Enter a Facebook username, page name, or URL.")
                val payload = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) {
                    raw
                } else {
                    "https://facebook.com/${raw.removePrefix("@")}"
                }
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "Facebook: $raw" })
            }

            QrCategory.YOUTUBE -> {
                val raw = state.socialHandleOrUrl.trim()
                if (raw.isEmpty()) return PayloadBuildResult.Invalid("Enter a YouTube channel handle or video URL.")
                val payload = when {
                    raw.startsWith("http://", true) || raw.startsWith("https://", true) -> raw
                    raw.startsWith("@") -> "https://youtube.com/$raw"
                    else -> "https://youtube.com/@$raw"
                }
                PayloadBuildResult.Valid(payload, state.title.ifBlank { "YouTube: $raw" })
            }

            QrCategory.CUSTOM -> {
                val raw = state.text.trim()
                if (raw.isEmpty()) return PayloadBuildResult.Invalid("Please enter custom QR content.")
                PayloadBuildResult.Valid(raw, state.title.ifBlank { "Custom: ${raw.take(28)}" })
            }
        }
    }

    private fun escapeWifiField(value: String): String {
        return value
            .replace("\\", "\\\\")
            .replace(";", "\\;")
            .replace(",", "\\,")
            .replace(":", "\\:")
    }
}
