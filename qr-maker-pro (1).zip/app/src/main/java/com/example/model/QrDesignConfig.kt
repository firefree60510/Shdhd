package com.example.model

import kotlinx.serialization.Serializable

@Serializable
enum class QrDotPattern(val label: String) {
    SQUARE("Square"),
    ROUNDED("Rounded"),
    DOTS("Dots"),
    PIXEL("Pixel"),
    DIAMOND("Diamond"),
    VERTICAL_BARS("Bars")
}

@Serializable
enum class QrCornerPattern(val label: String) {
    SQUARE("Square"),
    ROUNDED("Rounded"),
    CIRCLE("Circle"),
    LEAF("Leaf"),
    EXTRA_ROUNDED("Soft")
}

@Serializable
enum class QrCenterLogo(val label: String) {
    NONE("None"),
    GLOBE("Web"),
    PHONE("Phone"),
    CHAT("Chat"),
    EMAIL("Email"),
    WIFI("Wi-Fi"),
    CONTACT("Contact"),
    LOCATION("Map"),
    PAYMENT("Pay"),
    CAMERA("Social"),
    PLAY("Video"),
    SPARKLE("Brand"),
    CUSTOM_URI("Custom")
}

@Serializable
data class QrDesignConfig(
    val templateId: String = "classic",
    val foregroundColorArgb: Long = 0xFF0F172A,
    val gradientEndColorArgb: Long = 0xFF2563EB,
    val useGradient: Boolean = false,
    val backgroundColorArgb: Long = 0xFFFFFFFF,
    val dotPattern: QrDotPattern = QrDotPattern.SQUARE,
    val cornerPattern: QrCornerPattern = QrCornerPattern.SQUARE,
    val centerLogo: QrCenterLogo = QrCenterLogo.NONE,
    val customLogoUri: String? = null,
    val logoSizeRatio: Float = 0.20f,
    val quietZoneModules: Int = 4
)

enum class TemplateGroup(val label: String) {
    ALL("All"),
    ESSENTIALS("Essentials"),
    GRADIENTS("Gradients"),
    COLORS("Color Pop"),
    SOCIAL_BIZ("Social & Biz"),
    PREMIUM("Premium")
}

data class QrTemplate(
    val id: String,
    val name: String,
    val tagline: String,
    val group: TemplateGroup,
    val isPremium: Boolean,
    val config: QrDesignConfig
)

enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light Mode"),
    DARK("Dark Mode")
}
