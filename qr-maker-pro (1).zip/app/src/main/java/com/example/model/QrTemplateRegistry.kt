package com.example.model

/**
 * Scalable template registry for QR Maker.
 * Additional templates can be appended cleanly via [defaultTemplates] or registered dynamically via [registerTemplate].
 */
object QrTemplateRegistry {
    private val customTemplates = mutableListOf<QrTemplate>()

    private val defaultTemplates: List<QrTemplate> = listOf(
        QrTemplate(
            id = "classic",
            name = "Classic",
            tagline = "Timeless crisp contrast",
            group = TemplateGroup.ESSENTIALS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "classic",
                foregroundColorArgb = 0xFF0F172A,
                backgroundColorArgb = 0xFFFFFFFF,
                useGradient = false,
                dotPattern = QrDotPattern.SQUARE,
                cornerPattern = QrCornerPattern.SQUARE
            )
        ),
        QrTemplate(
            id = "gradient",
            name = "Gradient",
            tagline = "Indigo to royal blue flow",
            group = TemplateGroup.GRADIENTS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "gradient",
                foregroundColorArgb = 0xFF4F46E5,
                gradientEndColorArgb = 0xFF0284C7,
                useGradient = true,
                backgroundColorArgb = 0xFFFFFFFF,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.ROUNDED
            )
        ),
        QrTemplate(
            id = "neon",
            name = "Neon",
            tagline = "Electric glow on midnight",
            group = TemplateGroup.PREMIUM,
            isPremium = true,
            config = QrDesignConfig(
                templateId = "neon",
                foregroundColorArgb = 0xFF22D3EE,
                gradientEndColorArgb = 0xFFE879F9,
                useGradient = true,
                backgroundColorArgb = 0xFF090D1F,
                dotPattern = QrDotPattern.DOTS,
                cornerPattern = QrCornerPattern.ROUNDED
            )
        ),
        QrTemplate(
            id = "golden",
            name = "Golden",
            tagline = "Warm burnished gold",
            group = TemplateGroup.COLORS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "golden",
                foregroundColorArgb = 0xFF92400E,
                gradientEndColorArgb = 0xFFB45309,
                useGradient = true,
                backgroundColorArgb = 0xFFFFFBEB,
                dotPattern = QrDotPattern.DIAMOND,
                cornerPattern = QrCornerPattern.LEAF
            )
        ),
        QrTemplate(
            id = "blue",
            name = "Blue",
            tagline = "Vibrant cobalt clean",
            group = TemplateGroup.COLORS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "blue",
                foregroundColorArgb = 0xFF1D4ED8,
                backgroundColorArgb = 0xFFEFF6FF,
                useGradient = false,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.ROUNDED
            )
        ),
        QrTemplate(
            id = "purple",
            name = "Purple",
            tagline = "Royal violet studio",
            group = TemplateGroup.COLORS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "purple",
                foregroundColorArgb = 0xFF6D28D9,
                backgroundColorArgb = 0xFFF5F3FF,
                useGradient = false,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.EXTRA_ROUNDED
            )
        ),
        QrTemplate(
            id = "red",
            name = "Red",
            tagline = "Bold crimson signal",
            group = TemplateGroup.COLORS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "red",
                foregroundColorArgb = 0xFFDC2626,
                backgroundColorArgb = 0xFFFEF2F2,
                useGradient = false,
                dotPattern = QrDotPattern.SQUARE,
                cornerPattern = QrCornerPattern.ROUNDED
            )
        ),
        QrTemplate(
            id = "green",
            name = "Green",
            tagline = "Fresh emerald leaf",
            group = TemplateGroup.COLORS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "green",
                foregroundColorArgb = 0xFF047857,
                backgroundColorArgb = 0xFFECFDF5,
                useGradient = false,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.LEAF
            )
        ),
        QrTemplate(
            id = "rounded",
            name = "Rounded",
            tagline = "Smooth tactile corners",
            group = TemplateGroup.ESSENTIALS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "rounded",
                foregroundColorArgb = 0xFF312E81,
                backgroundColorArgb = 0xFFFFFFFF,
                useGradient = false,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.EXTRA_ROUNDED
            )
        ),
        QrTemplate(
            id = "dots",
            name = "Dots",
            tagline = "Geometric circle matrix",
            group = TemplateGroup.ESSENTIALS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "dots",
                foregroundColorArgb = 0xFF1E293B,
                backgroundColorArgb = 0xFFFFFFFF,
                useGradient = false,
                dotPattern = QrDotPattern.DOTS,
                cornerPattern = QrCornerPattern.CIRCLE
            )
        ),
        QrTemplate(
            id = "pixel",
            name = "Pixel",
            tagline = "Retro 8-bit micro grid",
            group = TemplateGroup.ESSENTIALS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "pixel",
                foregroundColorArgb = 0xFF18181B,
                backgroundColorArgb = 0xFFFAFAFA,
                useGradient = false,
                dotPattern = QrDotPattern.PIXEL,
                cornerPattern = QrCornerPattern.SQUARE
            )
        ),
        QrTemplate(
            id = "minimal",
            name = "Minimal",
            tagline = "Airy slate & pure space",
            group = TemplateGroup.ESSENTIALS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "minimal",
                foregroundColorArgb = 0xFF334155,
                backgroundColorArgb = 0xFFFFFFFF,
                useGradient = false,
                dotPattern = QrDotPattern.VERTICAL_BARS,
                cornerPattern = QrCornerPattern.ROUNDED,
                quietZoneModules = 5
            )
        ),
        QrTemplate(
            id = "business",
            name = "Business",
            tagline = "Executive navy gradient",
            group = TemplateGroup.SOCIAL_BIZ,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "business",
                foregroundColorArgb = 0xFF0F172A,
                gradientEndColorArgb = 0xFF1D4ED8,
                useGradient = true,
                backgroundColorArgb = 0xFFFFFFFF,
                dotPattern = QrDotPattern.SQUARE,
                cornerPattern = QrCornerPattern.ROUNDED,
                centerLogo = QrCenterLogo.CONTACT
            )
        ),
        QrTemplate(
            id = "creative",
            name = "Creative",
            tagline = "Artistic violet & coral",
            group = TemplateGroup.GRADIENTS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "creative",
                foregroundColorArgb = 0xFF7C3AED,
                gradientEndColorArgb = 0xFFF43F5E,
                useGradient = true,
                backgroundColorArgb = 0xFFFFFFFF,
                dotPattern = QrDotPattern.DOTS,
                cornerPattern = QrCornerPattern.LEAF,
                centerLogo = QrCenterLogo.SPARKLE
            )
        ),
        QrTemplate(
            id = "premium",
            name = "Premium",
            tagline = "Obsidian & champagne gold",
            group = TemplateGroup.PREMIUM,
            isPremium = true,
            config = QrDesignConfig(
                templateId = "premium",
                foregroundColorArgb = 0xFFF59E0B,
                gradientEndColorArgb = 0xFFFDE68A,
                useGradient = true,
                backgroundColorArgb = 0xFF0F172A,
                dotPattern = QrDotPattern.DIAMOND,
                cornerPattern = QrCornerPattern.LEAF,
                centerLogo = QrCenterLogo.SPARKLE
            )
        ),
        QrTemplate(
            id = "instagram",
            name = "Instagram",
            tagline = "Sunset magenta gradient",
            group = TemplateGroup.SOCIAL_BIZ,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "instagram",
                foregroundColorArgb = 0xFF833AB4,
                gradientEndColorArgb = 0xFFE1306C,
                useGradient = true,
                backgroundColorArgb = 0xFFFFFFFF,
                dotPattern = QrDotPattern.DOTS,
                cornerPattern = QrCornerPattern.EXTRA_ROUNDED,
                centerLogo = QrCenterLogo.CAMERA
            )
        ),
        QrTemplate(
            id = "whatsapp",
            name = "WhatsApp",
            tagline = "Messaging emerald",
            group = TemplateGroup.SOCIAL_BIZ,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "whatsapp",
                foregroundColorArgb = 0xFF075E54,
                gradientEndColorArgb = 0xFF128C7E,
                useGradient = true,
                backgroundColorArgb = 0xFFF0FDF4,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.ROUNDED,
                centerLogo = QrCenterLogo.CHAT
            )
        ),
        QrTemplate(
            id = "dark",
            name = "Dark",
            tagline = "High-contrast slate night",
            group = TemplateGroup.ESSENTIALS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "dark",
                foregroundColorArgb = 0xFFF8FAFC,
                backgroundColorArgb = 0xFF0F172A,
                useGradient = false,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.ROUNDED
            )
        ),
        QrTemplate(
            id = "colorful",
            name = "Colorful",
            tagline = "Vibrant prism spectrum",
            group = TemplateGroup.PREMIUM,
            isPremium = true,
            config = QrDesignConfig(
                templateId = "colorful",
                foregroundColorArgb = 0xFF6366F1,
                gradientEndColorArgb = 0xFFEC4899,
                useGradient = true,
                backgroundColorArgb = 0xFFFFFFFF,
                dotPattern = QrDotPattern.DOTS,
                cornerPattern = QrCornerPattern.CIRCLE
            )
        ),
        QrTemplate(
            id = "modern",
            name = "Modern",
            tagline = "Studio indigo & cyan",
            group = TemplateGroup.GRADIENTS,
            isPremium = false,
            config = QrDesignConfig(
                templateId = "modern",
                foregroundColorArgb = 0xFF312E81,
                gradientEndColorArgb = 0xFF0284C7,
                useGradient = true,
                backgroundColorArgb = 0xFFF8FAFC,
                dotPattern = QrDotPattern.ROUNDED,
                cornerPattern = QrCornerPattern.LEAF
            )
        ),
        QrTemplate(
            id = "cyber",
            name = "Cyber",
            tagline = "Electric violet & cyan",
            group = TemplateGroup.PREMIUM,
            isPremium = true,
            config = QrDesignConfig(
                templateId = "cyber",
                foregroundColorArgb = 0xFF38BDF8,
                gradientEndColorArgb = 0xFFA855F7,
                useGradient = true,
                backgroundColorArgb = 0xFF0B1120,
                dotPattern = QrDotPattern.PIXEL,
                cornerPattern = QrCornerPattern.EXTRA_ROUNDED
            )
        ),
        QrTemplate(
            id = "royal",
            name = "Royal",
            tagline = "Deep sapphire & amethyst",
            group = TemplateGroup.PREMIUM,
            isPremium = true,
            config = QrDesignConfig(
                templateId = "royal",
                foregroundColorArgb = 0xFF1E3A8A,
                gradientEndColorArgb = 0xFF7C3AED,
                useGradient = true,
                backgroundColorArgb = 0xFFF8FAFF,
                dotPattern = QrDotPattern.DIAMOND,
                cornerPattern = QrCornerPattern.CIRCLE
            )
        )
    )

    fun getAllTemplates(): List<QrTemplate> = defaultTemplates + customTemplates

    fun getTemplatesForGroup(group: TemplateGroup): List<QrTemplate> {
        val all = getAllTemplates()
        return if (group == TemplateGroup.ALL) all else all.filter { it.group == group }
    }

    fun getById(id: String): QrTemplate {
        return getAllTemplates().firstOrNull { it.id == id } ?: defaultTemplates.first()
    }

    fun registerTemplate(template: QrTemplate) {
        if (getAllTemplates().none { it.id == template.id }) {
            customTemplates.add(template)
        }
    }
}
