package com.example.data

import com.example.model.QrCategory
import com.example.model.QrDesignConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class QrHistoryRepository(private val dao: QrHistoryDao) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val allHistory: Flow<List<QrHistoryEntity>> = dao.getAllHistory()
    val generatedHistory: Flow<List<QrHistoryEntity>> = dao.getGeneratedHistory()
    val scannedHistory: Flow<List<QrHistoryEntity>> = dao.getScannedHistory()

    suspend fun saveGeneratedQr(
        title: String,
        content: String,
        category: QrCategory,
        designConfig: QrDesignConfig,
        existingId: Long? = null
    ): Long {
        val designJson = json.encodeToString(designConfig)
        val entity = QrHistoryEntity(
            id = existingId ?: 0L,
            title = title,
            content = content,
            categoryName = category.name,
            designJson = designJson,
            isScanned = false,
            createdAt = System.currentTimeMillis()
        )
        return dao.insert(entity)
    }

    suspend fun saveScannedQr(
        title: String,
        content: String,
        detectedCategory: QrCategory
    ): Long {
        val designJson = json.encodeToString(QrDesignConfig())
        return dao.insert(
            QrHistoryEntity(
                title = title,
                content = content,
                categoryName = detectedCategory.name,
                designJson = designJson,
                isScanned = true,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    fun decodeDesign(designJson: String): QrDesignConfig {
        return runCatching { json.decodeFromString<QrDesignConfig>(designJson) }
            .getOrDefault(QrDesignConfig())
    }

    fun encodeDesign(config: QrDesignConfig): String {
        return json.encodeToString(config)
    }

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun clearAll() = dao.clearAll()

    suspend fun clearByType(isScanned: Boolean) = dao.clearByType(isScanned)
}
