package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface QrHistoryDao {
    @Query("SELECT * FROM qr_history ORDER BY createdAt DESC")
    fun getAllHistory(): Flow<List<QrHistoryEntity>>

    @Query("SELECT * FROM qr_history WHERE isScanned = 0 ORDER BY createdAt DESC")
    fun getGeneratedHistory(): Flow<List<QrHistoryEntity>>

    @Query("SELECT * FROM qr_history WHERE isScanned = 1 ORDER BY createdAt DESC")
    fun getScannedHistory(): Flow<List<QrHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: QrHistoryEntity): Long

    @Update
    suspend fun update(item: QrHistoryEntity)

    @Query("DELETE FROM qr_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM qr_history WHERE isScanned = :isScanned")
    suspend fun clearByType(isScanned: Boolean)

    @Query("DELETE FROM qr_history")
    suspend fun clearAll()
}
