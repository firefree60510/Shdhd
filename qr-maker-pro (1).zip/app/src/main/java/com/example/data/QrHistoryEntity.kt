package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "qr_history")
data class QrHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val categoryName: String,
    val designJson: String,
    val isScanned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
