package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Centralized manager for Google Mobile Ads (Banner, Native, Interstitial, Rewarded)
 * and UMP Consent gathering.
 */
object AdManager {
    private const val TAG = "QrMakerAdManager"
    private const val INTERSTITIAL_COOLDOWN_MS = 90_000L
    private const val ACTIONS_PER_INTERSTITIAL = 3

    private val isMobileAdsInitStarted = AtomicBoolean(false)
    private var isSdkInitialized = false

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false
    private var lastInterstitialShownMs: Long = 0L
    private var completedActionsSinceAd: Int = 0

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    private val _isRewardedAdReady = MutableStateFlow(false)
    val isRewardedAdReady: StateFlow<Boolean> = _isRewardedAdReady.asStateFlow()

    private val _isPrivacyOptionsRequired = MutableStateFlow(false)
    val isPrivacyOptionsRequired: StateFlow<Boolean> = _isPrivacyOptionsRequired.asStateFlow()

    private val _canRequestAds = MutableStateFlow(false)
    val canRequestAds: StateFlow<Boolean> = _canRequestAds.asStateFlow()

    fun initialize(activity: Activity) {
        val consentInfo = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        consentInfo.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { loadAndShowError ->
                    if (loadAndShowError != null) {
                        Log.w(TAG, "Consent form notice: ${loadAndShowError.message}")
                    }
                    _isPrivacyOptionsRequired.value =
                        consentInfo.privacyOptionsRequirementStatus ==
                            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
                    if (consentInfo.canRequestAds()) {
                        startMobileAdsSdk(activity.applicationContext)
                    }
                }
            },
            { requestConsentError ->
                Log.w(TAG, "Consent info update skipped/failed: ${requestConsentError.message}")
                if (consentInfo.canRequestAds()) {
                    startMobileAdsSdk(activity.applicationContext)
                }
            }
        )

        if (consentInfo.canRequestAds()) {
            startMobileAdsSdk(activity.applicationContext)
        }
    }

    private fun startMobileAdsSdk(appContext: Context) {
        _canRequestAds.value = true
        if (isMobileAdsInitStarted.getAndSet(true)) return

        MobileAds.initialize(appContext) {
            isSdkInitialized = true
            preloadInterstitial(appContext)
            preloadRewarded(appContext)
        }
    }

    fun showPrivacyOptionsForm(activity: Activity, onDismissed: (String?) -> Unit = {}) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { formError ->
            onDismissed(formError?.message)
        }
    }

    fun preloadInterstitial(context: Context) {
        if (!_canRequestAds.value || isInterstitialLoading || interstitialAd != null) return
        isInterstitialLoading = true
        InterstitialAd.load(
            context.applicationContext,
            AdConfig.interstitialAdUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    isInterstitialLoading = false
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isInterstitialLoading = false
                    interstitialAd = null
                    Log.d(TAG, "Interstitial failed to load: ${error.message}")
                }
            }
        )
    }

    /**
     * Records a completed non-critical action (e.g. QR generated/saved) and shows an
     * interstitial only when frequency and cooldown rules are satisfied.
     */
    fun recordActionAndMaybeShowInterstitial(activity: Activity?) {
        if (activity == null || !_canRequestAds.value) return
        completedActionsSinceAd++

        val now = System.currentTimeMillis()
        val elapsed = now - lastInterstitialShownMs
        if (completedActionsSinceAd < ACTIONS_PER_INTERSTITIAL || elapsed < INTERSTITIAL_COOLDOWN_MS) {
            if (interstitialAd == null) preloadInterstitial(activity)
            return
        }

        val ad = interstitialAd
        if (ad == null) {
            preloadInterstitial(activity)
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                lastInterstitialShownMs = System.currentTimeMillis()
                completedActionsSinceAd = 0
                preloadInterstitial(activity.applicationContext)
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                interstitialAd = null
                preloadInterstitial(activity.applicationContext)
            }
        }
        interstitialAd = null
        ad.show(activity)
    }

    fun preloadRewarded(context: Context) {
        if (!_canRequestAds.value || isRewardedLoading || rewardedAd != null) return
        isRewardedLoading = true
        RewardedAd.load(
            context.applicationContext,
            AdConfig.rewardedAdUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    isRewardedLoading = false
                    rewardedAd = ad
                    _isRewardedAdReady.value = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    isRewardedLoading = false
                    rewardedAd = null
                    _isRewardedAdReady.value = false
                    Log.d(TAG, "Rewarded failed to load: ${error.message}")
                }
            }
        )
    }

    /**
     * Displays a Google AdMob Rewarded Ad.
     * [onRewardEarned] is strictly invoked only when the SDK confirms the user earned the reward.
     */
    fun showRewardedAd(
        activity: Activity?,
        onRewardEarned: () -> Unit,
        onAdNotAvailable: (String) -> Unit
    ) {
        if (activity == null) {
            onAdNotAvailable("Unable to show ad right now.")
            return
        }
        val ad = rewardedAd
        if (ad == null) {
            preloadRewarded(activity.applicationContext)
            onAdNotAvailable("Ad is still loading. Please try again in a moment.")
            return
        }

        var rewardGranted = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                _isRewardedAdReady.value = false
                preloadRewarded(activity.applicationContext)
                if (!rewardGranted) {
                    onAdNotAvailable("Watch the complete ad to claim this reward.")
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                rewardedAd = null
                _isRewardedAdReady.value = false
                preloadRewarded(activity.applicationContext)
                onAdNotAvailable("Ad couldn't be displayed right now. Please try again.")
            }
        }

        rewardedAd = null
        _isRewardedAdReady.value = false
        ad.show(activity) { _ ->
            rewardGranted = true
            onRewardEarned()
        }
    }
}
