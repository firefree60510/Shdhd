package com.example.ads

import com.example.BuildConfig

/**
 * Centralized Google AdMob configuration.
 *
 * During development and debug builds, official Google AdMob test ad unit IDs are used
 * to comply with AdMob invalid-traffic policies.
 * Before publishing to Google Play, replace the production IDs below with your real
 * AdMob App ID (also in AndroidManifest.xml) and ad unit IDs.
 */
object AdConfig {
    // Toggle to false only when valid production AdMob unit IDs are configured below.
    val useTestAds: Boolean = BuildConfig.DEBUG || PRODUCTION_BANNER_ID.startsWith("ca-app-pub-3940256099942544")

    // Official Google AdMob Test Ad Unit IDs
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    private const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // Production AdMob Unit IDs (configure before release)
    const val PRODUCTION_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val PRODUCTION_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val PRODUCTION_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val PRODUCTION_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val PRODUCTION_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    val bannerAdUnitId: String
        get() = if (useTestAds) TEST_BANNER_ID else PRODUCTION_BANNER_ID

    val interstitialAdUnitId: String
        get() = if (useTestAds) TEST_INTERSTITIAL_ID else PRODUCTION_INTERSTITIAL_ID

    val nativeAdUnitId: String
        get() = if (useTestAds) TEST_NATIVE_ID else PRODUCTION_NATIVE_ID

    val rewardedAdUnitId: String
        get() = if (useTestAds) TEST_REWARDED_ID else PRODUCTION_REWARDED_ID
}
