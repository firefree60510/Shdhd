package com.example.ads

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * Genuine Google AdMob Adaptive Banner Ad.
 * Collapses cleanly when ads cannot be requested or fail to load—never renders fake ads.
 */
@Composable
fun AdMobBanner(
    modifier: Modifier = Modifier,
    adUnitId: String = AdConfig.bannerAdUnitId
) {
    val canRequestAds by AdManager.canRequestAds.collectAsState()
    if (!canRequestAds) return

    val context = LocalContext.current
    var isAdLoaded by remember { mutableStateOf(false) }

    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val widthDp = maxWidth.value.toInt().coerceAtLeast(320)
        val adView = remember(adUnitId, widthDp) {
            AdView(context).apply {
                this.adUnitId = adUnitId
                setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp))
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        isAdLoaded = true
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        isAdLoaded = false
                    }
                }
                loadAd(AdRequest.Builder().build())
            }
        }

        DisposableEffect(adView) {
            onDispose { adView.destroy() }
        }

        AnimatedVisibility(visible = isAdLoaded) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                AndroidView(
                    factory = { adView },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

/**
 * Genuine Google AdMob Native Advanced Ad rendered with NativeAdView.
 * Displays only when a real NativeAd is loaded by the SDK.
 */
@Composable
fun AdMobNativeAdCard(
    modifier: Modifier = Modifier,
    adUnitId: String = AdConfig.nativeAdUnitId
) {
    val canRequestAds by AdManager.canRequestAds.collectAsState()
    if (!canRequestAds) return

    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(adUnitId) {
        var activeAd: NativeAd? = null
        val loader = AdLoader.Builder(context, adUnitId)
            .forNativeAd { ad ->
                activeAd?.destroy()
                activeAd = ad
                nativeAd = ad
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    nativeAd = null
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()

        loader.loadAd(AdRequest.Builder().build())

        onDispose {
            activeAd?.destroy()
            nativeAd = null
        }
    }

    val loadedAd = nativeAd ?: return
    val surfaceColor = MaterialTheme.colorScheme.surface.toArgb()
    val titleColor = MaterialTheme.colorScheme.onSurface.toArgb()
    val bodyColor = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()
    val primaryColor = MaterialTheme.colorScheme.primary.toArgb()
    val onPrimaryColor = MaterialTheme.colorScheme.onPrimary.toArgb()
    val badgeBgColor = MaterialTheme.colorScheme.primaryContainer.toArgb()
    val badgeTextColor = MaterialTheme.colorScheme.onPrimaryContainer.toArgb()

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 2.dp
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            factory = { ctx ->
                buildNativeAdView(
                    context = ctx,
                    surfaceColor = surfaceColor,
                    titleColor = titleColor,
                    bodyColor = bodyColor,
                    primaryColor = primaryColor,
                    onPrimaryColor = onPrimaryColor,
                    badgeBgColor = badgeBgColor,
                    badgeTextColor = badgeTextColor
                )
            },
            update = { adView ->
                populateNativeAdView(loadedAd, adView)
            }
        )
    }
}

private fun buildNativeAdView(
    context: Context,
    surfaceColor: Int,
    titleColor: Int,
    bodyColor: Int,
    primaryColor: Int,
    onPrimaryColor: Int,
    badgeBgColor: Int,
    badgeTextColor: Int
): NativeAdView {
    val density = context.resources.displayMetrics.density
    fun dp(v: Int): Int = (v * density).toInt()

    val nativeAdView = NativeAdView(context).apply {
        setBackgroundColor(surfaceColor)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    val root = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    val headerRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    val iconView = ImageView(context).apply {
        id = View.generateViewId()
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply {
            marginEnd = dp(12)
        }
        scaleType = ImageView.ScaleType.CENTER_CROP
    }

    val titleColumn = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    }

    val adBadge = TextView(context).apply {
        text = "Ad"
        textSize = 10f
        setTextColor(badgeTextColor)
        setPadding(dp(6), dp(2), dp(6), dp(2))
        background = GradientDrawable().apply {
            setColor(badgeBgColor)
            cornerRadius = dp(6).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(4) }
    }

    val headlineView = TextView(context).apply {
        id = View.generateViewId()
        textSize = 15f
        setTextColor(titleColor)
        paint.isFakeBoldText = true
        maxLines = 2
    }

    val advertiserView = TextView(context).apply {
        id = View.generateViewId()
        textSize = 12f
        setTextColor(bodyColor)
        maxLines = 1
    }

    titleColumn.addView(adBadge)
    titleColumn.addView(headlineView)
    titleColumn.addView(advertiserView)

    headerRow.addView(iconView)
    headerRow.addView(titleColumn)
    root.addView(headerRow)

    val mediaView = MediaView(context).apply {
        id = View.generateViewId()
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(136)
        ).apply {
            topMargin = dp(10)
            bottomMargin = dp(8)
        }
    }
    root.addView(mediaView)

    val bodyView = TextView(context).apply {
        id = View.generateViewId()
        textSize = 13f
        setTextColor(bodyColor)
        maxLines = 2
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) }
    }
    root.addView(bodyView)

    val ctaButton = Button(context).apply {
        id = View.generateViewId()
        setTextColor(onPrimaryColor)
        textSize = 13f
        isAllCaps = false
        background = GradientDrawable().apply {
            setColor(primaryColor)
            cornerRadius = dp(12).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(48)
        )
    }
    root.addView(ctaButton)

    nativeAdView.addView(root)
    nativeAdView.iconView = iconView
    nativeAdView.headlineView = headlineView
    nativeAdView.advertiserView = advertiserView
    nativeAdView.mediaView = mediaView
    nativeAdView.bodyView = bodyView
    nativeAdView.callToActionView = ctaButton

    return nativeAdView
}

private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
    (adView.headlineView as? TextView)?.text = nativeAd.headline

    val iconView = adView.iconView as? ImageView
    if (nativeAd.icon != null) {
        iconView?.setImageDrawable(nativeAd.icon?.drawable)
        iconView?.visibility = View.VISIBLE
    } else {
        iconView?.visibility = View.GONE
    }

    val advertiserView = adView.advertiserView as? TextView
    if (!nativeAd.advertiser.isNullOrBlank()) {
        advertiserView?.text = nativeAd.advertiser
        advertiserView?.visibility = View.VISIBLE
    } else {
        advertiserView?.visibility = View.GONE
    }

    val bodyView = adView.bodyView as? TextView
    if (!nativeAd.body.isNullOrBlank()) {
        bodyView?.text = nativeAd.body
        bodyView?.visibility = View.VISIBLE
    } else {
        bodyView?.visibility = View.GONE
    }

    val mediaView = adView.mediaView
    if (nativeAd.mediaContent != null && mediaView != null) {
        mediaView.mediaContent = nativeAd.mediaContent
        mediaView.visibility = View.VISIBLE
    } else {
        mediaView?.visibility = View.GONE
    }

    val ctaView = adView.callToActionView as? Button
    if (!nativeAd.callToAction.isNullOrBlank()) {
        ctaView?.text = nativeAd.callToAction
        ctaView?.visibility = View.VISIBLE
    } else {
        ctaView?.visibility = View.GONE
    }

    adView.setNativeAd(nativeAd)
}
