package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.QrDesignConfig
import com.example.model.QrTemplate
import com.example.ui.components.QrExportActions
import com.example.ui.components.QrPreviewCard

@Composable
fun DesignStudioScreen(
    payload: String,
    title: String,
    designConfig: QrDesignConfig,
    premiumUnlocked: Boolean,
    onApplyTemplate: (QrTemplate) -> Boolean,
    onUpdateDesign: ((QrDesignConfig) -> QrDesignConfig) -> Unit,
    onUnlockPremium: () -> Unit,
    onSaveToHistory: () -> Unit,
    onStatusMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Templates", "Colors", "Patterns", "Logo")

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 720.dp

        if (isWideScreen) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.weight(0.45f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Text(
                            text = "QR Design Studio",
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }
                    item {
                        QrPreviewCard(
                            payload = payload,
                            title = title,
                            designConfig = designConfig,
                            previewSize = 240.dp
                        )
                    }
                    item {
                        QrExportActions(
                            payload = payload,
                            title = title,
                            designConfig = designConfig,
                            onSaveToHistory = onSaveToHistory,
                            onStatusMessage = onStatusMessage
                        )
                    }
                }

                Column(modifier = Modifier.weight(0.55f)) {
                    StudioTabsBar(tabs = tabs, selectedTab = selectedTab, onSelect = { selectedTab = it })
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            StudioTabContent(
                                selectedTab = selectedTab,
                                designConfig = designConfig,
                                premiumUnlocked = premiumUnlocked,
                                onApplyTemplate = onApplyTemplate,
                                onUpdateDesign = onUpdateDesign,
                                onUnlockPremium = onUnlockPremium,
                                onStatusMessage = onStatusMessage
                            )
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Column(modifier = Modifier.widthIn(max = 760.dp).fillMaxWidth()) {
                        Text(
                            text = "QR Design Studio",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Real-time customization with 22+ scannable styles",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                item {
                    BoxWithConstraints(modifier = Modifier.widthIn(max = 760.dp).fillMaxWidth()) {
                        QrPreviewCard(
                            payload = payload,
                            title = title,
                            designConfig = designConfig,
                            previewSize = 210.dp
                        )
                    }
                }

                item {
                    Column(modifier = Modifier.widthIn(max = 760.dp).fillMaxWidth()) {
                        StudioTabsBar(tabs = tabs, selectedTab = selectedTab, onSelect = { selectedTab = it })
                        Spacer(modifier = Modifier.height(12.dp))
                        StudioTabContent(
                            selectedTab = selectedTab,
                            designConfig = designConfig,
                            premiumUnlocked = premiumUnlocked,
                            onApplyTemplate = onApplyTemplate,
                            onUpdateDesign = onUpdateDesign,
                            onUnlockPremium = onUnlockPremium,
                            onStatusMessage = onStatusMessage
                        )
                    }
                }

                item {
                    Column(modifier = Modifier.widthIn(max = 760.dp).fillMaxWidth()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        QrExportActions(
                            payload = payload,
                            title = title,
                            designConfig = designConfig,
                            onSaveToHistory = onSaveToHistory,
                            onStatusMessage = onStatusMessage
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioTabsBar(
    tabs: List<String>,
    selectedTab: Int,
    onSelect: (Int) -> Unit
) {
    TabRow(selectedTabIndex = selectedTab) {
        tabs.forEachIndexed { index, label ->
            Tab(
                selected = selectedTab == index,
                onClick = { onSelect(index) },
                text = { Text(label) },
                modifier = Modifier.testTag("studio_tab_${label.lowercase()}")
            )
        }
    }
}

@Composable
private fun StudioTabContent(
    selectedTab: Int,
    designConfig: QrDesignConfig,
    premiumUnlocked: Boolean,
    onApplyTemplate: (QrTemplate) -> Boolean,
    onUpdateDesign: ((QrDesignConfig) -> QrDesignConfig) -> Unit,
    onUnlockPremium: () -> Unit,
    onStatusMessage: (String) -> Unit
) {
    when (selectedTab) {
        0 -> TemplatesTabPanel(
            selectedTemplateId = designConfig.templateId,
            premiumUnlocked = premiumUnlocked,
            onApplyTemplate = { template ->
                if (onApplyTemplate(template)) {
                    onStatusMessage("Applied ${template.name} template")
                }
            },
            onUnlockPremium = onUnlockPremium,
            onStatusMessage = onStatusMessage
        )
        1 -> ColorsTabPanel(
            config = designConfig,
            onUpdateConfig = onUpdateDesign
        )
        2 -> PatternsTabPanel(
            config = designConfig,
            onUpdateConfig = onUpdateDesign
        )
        3 -> LogoTabPanel(
            config = designConfig,
            onUpdateConfig = onUpdateDesign,
            onStatusMessage = onStatusMessage
        )
    }
}
