package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
data class GeneratorRoute(val categoryName: String? = null)

@Serializable
object StudioRoute

@Serializable
object ScannerRoute

@Serializable
data class HistoryRoute(val initialTab: Int = 0)

@Serializable
object SettingsRoute
