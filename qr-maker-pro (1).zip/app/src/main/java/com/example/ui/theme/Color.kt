package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Tokens (Purple, Blue & Clean Porcelain White)
val IndigoPrimary = Color(0xFF4F46E5)
val OnIndigoPrimary = Color(0xFFFFFFFF)
val IndigoContainer = Color(0xFFE0E7FF)
val OnIndigoContainer = Color(0xFF1E1B4B)

val RoyalBlueSecondary = Color(0xFF2563EB)
val OnRoyalBlueSecondary = Color(0xFFFFFFFF)
val RoyalBlueContainer = Color(0xFFDBEAFE)
val OnRoyalBlueContainer = Color(0xFF172554)

val VioletTertiary = Color(0xFF7C3AED)
val OnVioletTertiary = Color(0xFFFFFFFF)
val VioletContainer = Color(0xFFEDE9FE)
val OnVioletContainer = Color(0xFF2E1065)

val LightBackground = Color(0xFFF7F8FC)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFEEF2FF)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFE2E8F0)
val LightOutlineVariant = Color(0xFFCBD5E1)

// Dark Theme Tokens (Midnight Navy, Luminous Indigo & Sky Blue)
val DarkIndigoPrimary = Color(0xFF818CF8)
val DarkOnIndigoPrimary = Color(0xFF1E1B4B)
val DarkIndigoContainer = Color(0xFF312E81)
val DarkOnIndigoContainer = Color(0xFFE0E7FF)

val DarkBlueSecondary = Color(0xFF60A5FA)
val DarkOnBlueSecondary = Color(0xFF0F172A)
val DarkBlueContainer = Color(0xFF1E3A8A)
val DarkOnBlueContainer = Color(0xFFDBEAFE)

val DarkVioletTertiary = Color(0xFFA78BFA)
val DarkOnVioletTertiary = Color(0xFF2E1065)
val DarkVioletContainer = Color(0xFF4C1D95)
val DarkOnVioletContainer = Color(0xFFEDE9FE)

val DarkBackground = Color(0xFF0B0F1A)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkSurface = Color(0xFF131A2A)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1B2438)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF2A3550)
val DarkOutlineVariant = Color(0xFF334155)

// Semantic Status Colors
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val SkyAccent = Color(0xFF0EA5E9)
