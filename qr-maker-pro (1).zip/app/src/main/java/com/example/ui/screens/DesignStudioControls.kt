package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ads.AdManager
import com.example.ads.AdMobNativeAdCard
import com.example.model.QrCenterLogo
import com.example.model.QrCornerPattern
import com.example.model.QrDesignConfig
import com.example.model.QrDotPattern
import com.example.model.QrTemplate
import com.example.model.QrTemplateRegistry
import com.example.model.TemplateGroup
import com.example.qr.QrBitmapRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@Composable
fun TemplatesTabPanel(
    selectedTemplateId: String,
    premiumUnlocked: Boolean,
    onApplyTemplate: (QrTemplate) -> Unit,
    onUnlockPremium: () -> Unit,
    onStatusMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var selectedGroup by remember { mutableStateOf(TemplateGroup.ALL) }
    val templates = remember(selectedGroup) {
        QrTemplateRegistry.getTemplatesForGroup(selectedGroup)
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!premiumUnlocked) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WorkspacePremium,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Unlock All Premium Designs",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Neon, Cyber, Royal, Colorful & Gold Obsidian",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            AdManager.showRewardedAd(
                                activity = activity,
                                onRewardEarned = onUnlockPremium,
                                onAdNotAvailable = onStatusMessage
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(48.dp).testTag("unlock_premium_ad_button")
                    ) {
                        Icon(Icons.Rounded.PlayCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Watch Ad")
                    }
                }
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(TemplateGroup.entries) { group ->
                FilterChip(
                    selected = selectedGroup == group,
                    onClick = { selectedGroup = group },
                    label = { Text(group.label) }
                )
            }
        }

        val firstBatch = templates.take(6)
        val remainingBatch = templates.drop(6)

        TemplateGrid(
            templates = firstBatch,
            selectedTemplateId = selectedTemplateId,
            premiumUnlocked = premiumUnlocked,
            onSelect = { template ->
                if (template.isPremium && !premiumUnlocked) {
                    AdManager.showRewardedAd(
                        activity = activity,
                        onRewardEarned = {
                            onUnlockPremium()
                            onApplyTemplate(template)
                        },
                        onAdNotAvailable = onStatusMessage
                    )
                } else {
                    onApplyTemplate(template)
                }
            }
        )

        if (remainingBatch.isNotEmpty()) {
            // Native Ad seamlessly placed between template sections
            AdMobNativeAdCard()

            TemplateGrid(
                templates = remainingBatch,
                selectedTemplateId = selectedTemplateId,
                premiumUnlocked = premiumUnlocked,
                onSelect = { template ->
                    if (template.isPremium && !premiumUnlocked) {
                        AdManager.showRewardedAd(
                            activity = activity,
                            onRewardEarned = {
                                onUnlockPremium()
                                onApplyTemplate(template)
                            },
                            onAdNotAvailable = onStatusMessage
                        )
                    } else {
                        onApplyTemplate(template)
                    }
                }
            )
        }
    }
}

@Composable
private fun TemplateGrid(
    templates: List<QrTemplate>,
    selectedTemplateId: String,
    premiumUnlocked: Boolean,
    onSelect: (QrTemplate) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        templates.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { template ->
                    val isSelected = template.id == selectedTemplateId
                    val isLocked = template.isPremium && !premiumUnlocked
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onSelect(template) }
                            .testTag("template_card_${template.id}"),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        ),
                        tonalElevation = if (isSelected) 3.dp else 1.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val fg1 = Color(template.config.foregroundColorArgb)
                            val fg2 = if (template.config.useGradient) Color(template.config.gradientEndColorArgb) else fg1
                            val bg = Color(template.config.backgroundColorArgb)

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(bg)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Brush.linearGradient(listOf(fg1, fg2)))
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = template.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (isLocked) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Rounded.Lock,
                                            contentDescription = "Locked premium template",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    } else if (template.isPremium) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Rounded.AutoAwesome,
                                            contentDescription = "Unlocked premium template",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = template.tagline,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun ColorsTabPanel(
    config: QrDesignConfig,
    onUpdateConfig: ((QrDesignConfig) -> QrDesignConfig) -> Unit
) {
    val fgPalette = listOf(
        0xFF0F172A, 0xFF4F46E5, 0xFF2563EB, 0xFF7C3AED, 0xFFDC2626,
        0xFF059669, 0xFFB45309, 0xFFE1306C, 0xFF0284C7, 0xFFF8FAFC
    )
    val bgPalette = listOf(
        0xFFFFFFFF, 0xFFF8FAFC, 0xFFEFF6FF, 0xFFF5F3FF, 0xFFFFFBEB,
        0xFFECFDF5, 0xFFFEF2F2, 0xFF0F172A, 0xFF090D1F, 0xFF18181B
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ColorSwatchSection(
            title = "Foreground Color",
            selectedArgb = config.foregroundColorArgb,
            swatches = fgPalette,
            onColorSelected = { argb -> onUpdateConfig { it.copy(foregroundColorArgb = argb) } }
        )

        RgbSlidersCard(
            label = "Custom Foreground RGB",
            argb = config.foregroundColorArgb,
            onArgbChange = { argb -> onUpdateConfig { it.copy(foregroundColorArgb = argb) } }
        )

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Gradient Foreground", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Blend two colors diagonally across modules",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = config.useGradient,
                        onCheckedChange = { checked -> onUpdateConfig { it.copy(useGradient = checked) } }
                    )
                }

                if (config.useGradient) {
                    Spacer(modifier = Modifier.height(10.dp))
                    ColorSwatchSection(
                        title = "Gradient End Color",
                        selectedArgb = config.gradientEndColorArgb,
                        swatches = fgPalette,
                        onColorSelected = { argb -> onUpdateConfig { it.copy(gradientEndColorArgb = argb) } }
                    )
                }
            }
        }

        ColorSwatchSection(
            title = "Background Color",
            selectedArgb = config.backgroundColorArgb,
            swatches = bgPalette,
            onColorSelected = { argb -> onUpdateConfig { it.copy(backgroundColorArgb = argb) } }
        )

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Quiet Zone Margin: ${config.quietZoneModules} modules",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "Maintains clean border padding for reliable scanning",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = config.quietZoneModules.toFloat(),
                    onValueChange = { v -> onUpdateConfig { it.copy(quietZoneModules = v.roundToInt().coerceIn(4, 8)) } },
                    valueRange = 4f..8f,
                    steps = 3
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorSwatchSection(
    title: String,
    selectedArgb: Long,
    swatches: List<Long>,
    onColorSelected: (Long) -> Unit
) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            swatches.forEach { argb ->
                val isSelected = argb == selectedArgb
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            shape = CircleShape
                        )
                        .clickable { onColorSelected(argb) },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        val isLight = argb == 0xFFFFFFFF || argb == 0xFFF8FAFC || argb == 0xFFEFF6FF ||
                            argb == 0xFFF5F3FF || argb == 0xFFFFFBEB || argb == 0xFFECFDF5 || argb == 0xFFFEF2F2
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Selected color",
                            tint = if (isLight) Color.Black else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RgbSlidersCard(
    label: String,
    argb: Long,
    onArgbChange: (Long) -> Unit
) {
    val intColor = argb.toInt()
    val r = AndroidColor.red(intColor)
    val g = AndroidColor.green(intColor)
    val b = AndroidColor.blue(intColor)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, style = MaterialTheme.typography.titleSmall)
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                )
            }
            RgbChannelSlider("R", r, Color(0xFFEF4444)) { newR ->
                onArgbChange((0xFF000000L or (newR.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()))
            }
            RgbChannelSlider("G", g, Color(0xFF10B981)) { newG ->
                onArgbChange((0xFF000000L or (r.toLong() shl 16) or (newG.toLong() shl 8) or b.toLong()))
            }
            RgbChannelSlider("B", b, Color(0xFF2563EB)) { newB ->
                onArgbChange((0xFF000000L or (r.toLong() shl 16) or (g.toLong() shl 8) or newB.toLong()))
            }
        }
    }
}

@Composable
private fun RgbChannelSlider(
    channel: String,
    value: Int,
    color: Color,
    onValueChange: (Int) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(channel, style = MaterialTheme.typography.labelMedium, color = color, modifier = Modifier.width(18.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.roundToInt().coerceIn(0, 255)) },
            valueRange = 0f..255f,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.width(32.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PatternsTabPanel(
    config: QrDesignConfig,
    onUpdateConfig: ((QrDesignConfig) -> QrDesignConfig) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text("QR Dot Pattern", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QrDotPattern.entries.forEach { pattern ->
                    FilterChip(
                        selected = config.dotPattern == pattern,
                        onClick = { onUpdateConfig { it.copy(dotPattern = pattern) } },
                        label = { Text(pattern.label) },
                        modifier = Modifier.testTag("dot_pattern_${pattern.name.lowercase()}")
                    )
                }
            }
        }

        Column {
            Text("Corner Eye Pattern", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QrCornerPattern.entries.forEach { corner ->
                    FilterChip(
                        selected = config.cornerPattern == corner,
                        onClick = { onUpdateConfig { it.copy(cornerPattern = corner) } },
                        label = { Text(corner.label) },
                        modifier = Modifier.testTag("corner_pattern_${corner.name.lowercase()}")
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LogoTabPanel(
    config: QrDesignConfig,
    onUpdateConfig: ((QrDesignConfig) -> QrDesignConfig) -> Unit,
    onStatusMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val localUri = copyPickedLogoLocally(context, uri)
                if (localUri != null) {
                    onUpdateConfig {
                        it.copy(
                            centerLogo = QrCenterLogo.CUSTOM_URI,
                            customLogoUri = localUri
                        )
                    }
                    onStatusMessage("Custom logo applied!")
                } else {
                    onStatusMessage("Couldn't read selected image.")
                }
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("upload_custom_logo_button")
            ) {
                Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Upload Custom Logo")
            }

            if (config.centerLogo != QrCenterLogo.NONE) {
                OutlinedButton(
                    onClick = {
                        onUpdateConfig {
                            it.copy(centerLogo = QrCenterLogo.NONE, customLogoUri = null)
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.height(48.dp)
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Remove logo", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Remove")
                }
            }
        }

        Text("Built-in Center Badges", style = MaterialTheme.typography.titleMedium)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QrCenterLogo.entries
                .filter { it != QrCenterLogo.CUSTOM_URI }
                .forEach { logo ->
                    FilterChip(
                        selected = config.centerLogo == logo,
                        onClick = {
                            onUpdateConfig { it.copy(centerLogo = logo, customLogoUri = null) }
                        },
                        leadingIcon = if (logo != QrCenterLogo.NONE) {
                            {
                                Icon(
                                    imageVector = QrBitmapRenderer.iconForLogo(logo),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else null,
                        label = { Text(logo.label) }
                    )
                }
        }

        if (config.centerLogo != QrCenterLogo.NONE) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Logo Size: ${(config.logoSizeRatio * 100).roundToInt()}%",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "Capped at 22% to guarantee Error Correction H scannability",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = config.logoSizeRatio,
                        onValueChange = { ratio -> onUpdateConfig { it.copy(logoSizeRatio = ratio.coerceIn(0.14f, 0.22f)) } },
                        valueRange = 0.14f..0.22f
                    )
                }
            }
        }
    }
}

private suspend fun copyPickedLogoLocally(context: Context, sourceUri: Uri): String? =
    withContext(Dispatchers.IO) {
        runCatching {
            val logosDir = File(context.filesDir, "logos").apply { mkdirs() }
            val dest = File(logosDir, "logo_${System.currentTimeMillis()}.png")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                dest.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@runCatching null
            Uri.fromFile(dest).toString()
        }.getOrNull()
    }
