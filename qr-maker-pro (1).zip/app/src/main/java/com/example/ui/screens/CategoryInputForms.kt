package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.QrCategory
import com.example.model.QrFormState
import com.example.model.WifiSecurity

@Composable
fun CategoryInputForm(
    formState: QrFormState,
    onUpdateForm: ((QrFormState) -> QrFormState) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = formState.title,
            onValueChange = { v -> onUpdateForm { it.copy(title = v) } },
            label = { Text("Label / Title (Optional)") },
            placeholder = { Text("e.g. Office Wi-Fi or Portfolio") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("input_title")
        )

        when (formState.category) {
            QrCategory.URL -> {
                OutlinedTextField(
                    value = formState.url,
                    onValueChange = { v -> onUpdateForm { it.copy(url = v) } },
                    label = { Text("Website URL *") },
                    placeholder = { Text("https://example.com") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_url")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        onUpdateForm {
                            val current = it.url.trim()
                            if (current.startsWith("http")) it else it.copy(url = "https://$current")
                        }
                    }) {
                        Text("+ https://")
                    }
                    TextButton(onClick = {
                        onUpdateForm {
                            if (it.url.contains("www.")) it else it.copy(url = "https://www.")
                        }
                    }) {
                        Text("+ https://www.")
                    }
                }
            }

            QrCategory.TEXT, QrCategory.CUSTOM -> {
                OutlinedTextField(
                    value = formState.text,
                    onValueChange = { v -> onUpdateForm { it.copy(text = v) } },
                    label = { Text(if (formState.category == QrCategory.CUSTOM) "Custom QR Payload *" else "Plain Text *") },
                    placeholder = {
                        Text(
                            if (formState.category == QrCategory.CUSTOM)
                                "Enter any raw URI, JSON, token, or text"
                            else
                                "Write your note, coupon code, or message..."
                        )
                    },
                    minLines = 3,
                    maxLines = 6,
                    shape = RoundedCornerShape(14.dp),
                    supportingText = { Text("${formState.text.length} characters") },
                    modifier = Modifier.fillMaxWidth().testTag("input_text")
                )
            }

            QrCategory.PHONE -> {
                OutlinedTextField(
                    value = formState.phone,
                    onValueChange = { v -> onUpdateForm { it.copy(phone = v) } },
                    label = { Text("Phone Number *") },
                    placeholder = { Text("+1 555 234 5678") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_phone")
                )
            }

            QrCategory.WHATSAPP -> {
                OutlinedTextField(
                    value = formState.phone,
                    onValueChange = { v -> onUpdateForm { it.copy(phone = v) } },
                    label = { Text("WhatsApp Number (with Country Code) *") },
                    placeholder = { Text("15551234567") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_whatsapp_phone")
                )
                OutlinedTextField(
                    value = formState.message,
                    onValueChange = { v -> onUpdateForm { it.copy(message = v) } },
                    label = { Text("Pre-filled Message (Optional)") },
                    placeholder = { Text("Hello! I scanned your QR code.") },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_whatsapp_msg")
                )
            }

            QrCategory.EMAIL -> {
                OutlinedTextField(
                    value = formState.emailAddress,
                    onValueChange = { v -> onUpdateForm { it.copy(emailAddress = v) } },
                    label = { Text("Email Address *") },
                    placeholder = { Text("hello@company.com") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_email")
                )
                OutlinedTextField(
                    value = formState.emailSubject,
                    onValueChange = { v -> onUpdateForm { it.copy(emailSubject = v) } },
                    label = { Text("Subject (Optional)") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_email_subject")
                )
                OutlinedTextField(
                    value = formState.emailBody,
                    onValueChange = { v -> onUpdateForm { it.copy(emailBody = v) } },
                    label = { Text("Body (Optional)") },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_email_body")
                )
            }

            QrCategory.SMS -> {
                OutlinedTextField(
                    value = formState.phone,
                    onValueChange = { v -> onUpdateForm { it.copy(phone = v) } },
                    label = { Text("Recipient Phone Number *") },
                    placeholder = { Text("+1 555 987 6543") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_sms_phone")
                )
                OutlinedTextField(
                    value = formState.message,
                    onValueChange = { v -> onUpdateForm { it.copy(message = v) } },
                    label = { Text("SMS Message (Optional)") },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_sms_msg")
                )
            }

            QrCategory.WIFI -> {
                OutlinedTextField(
                    value = formState.wifiSsid,
                    onValueChange = { v -> onUpdateForm { it.copy(wifiSsid = v) } },
                    label = { Text("Network Name (SSID) *") },
                    placeholder = { Text("MyHomeWiFi") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_wifi_ssid")
                )
                if (formState.wifiSecurity != WifiSecurity.NONE) {
                    OutlinedTextField(
                        value = formState.wifiPassword,
                        onValueChange = { v -> onUpdateForm { it.copy(wifiPassword = v) } },
                        label = { Text("Password *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("input_wifi_password")
                    )
                }
                Text("Security Protocol", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WifiSecurity.entries.forEach { sec ->
                        FilterChip(
                            selected = formState.wifiSecurity == sec,
                            onClick = { onUpdateForm { it.copy(wifiSecurity = sec) } },
                            label = { Text(sec.label) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Hidden Network", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = formState.wifiHidden,
                        onCheckedChange = { checked -> onUpdateForm { it.copy(wifiHidden = checked) } }
                    )
                }
            }

            QrCategory.VCARD -> {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = formState.firstName,
                        onValueChange = { v -> onUpdateForm { it.copy(firstName = v) } },
                        label = { Text("First Name *") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("input_vcard_first")
                    )
                    OutlinedTextField(
                        value = formState.lastName,
                        onValueChange = { v -> onUpdateForm { it.copy(lastName = v) } },
                        label = { Text("Last Name") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("input_vcard_last")
                    )
                }
                OutlinedTextField(
                    value = formState.vcardPhone,
                    onValueChange = { v -> onUpdateForm { it.copy(vcardPhone = v) } },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_vcard_phone")
                )
                OutlinedTextField(
                    value = formState.vcardEmail,
                    onValueChange = { v -> onUpdateForm { it.copy(vcardEmail = v) } },
                    label = { Text("Email") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_vcard_email")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = formState.organization,
                        onValueChange = { v -> onUpdateForm { it.copy(organization = v) } },
                        label = { Text("Company") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = formState.jobTitle,
                        onValueChange = { v -> onUpdateForm { it.copy(jobTitle = v) } },
                        label = { Text("Job Title") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = formState.vcardWebsite,
                    onValueChange = { v -> onUpdateForm { it.copy(vcardWebsite = v) } },
                    label = { Text("Website") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = formState.vcardAddress,
                    onValueChange = { v -> onUpdateForm { it.copy(vcardAddress = v) } },
                    label = { Text("Address") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            QrCategory.LOCATION -> {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = formState.latitude,
                        onValueChange = { v -> onUpdateForm { it.copy(latitude = v) } },
                        label = { Text("Latitude *") },
                        placeholder = { Text("37.7749") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("input_latitude")
                    )
                    OutlinedTextField(
                        value = formState.longitude,
                        onValueChange = { v -> onUpdateForm { it.copy(longitude = v) } },
                        label = { Text("Longitude *") },
                        placeholder = { Text("-122.4194") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("input_longitude")
                    )
                }
                OutlinedTextField(
                    value = formState.locationLabel,
                    onValueChange = { v -> onUpdateForm { it.copy(locationLabel = v) } },
                    label = { Text("Place Label (Optional)") },
                    placeholder = { Text("San Francisco HQ") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            QrCategory.UPI -> {
                OutlinedTextField(
                    value = formState.upiId,
                    onValueChange = { v -> onUpdateForm { it.copy(upiId = v) } },
                    label = { Text("UPI ID (VPA) *") },
                    placeholder = { Text("merchant@upi") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_upi_id")
                )
                OutlinedTextField(
                    value = formState.upiPayeeName,
                    onValueChange = { v -> onUpdateForm { it.copy(upiPayeeName = v) } },
                    label = { Text("Payee Name *") },
                    placeholder = { Text("Alex Store") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_upi_name")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = formState.upiAmount,
                        onValueChange = { v -> onUpdateForm { it.copy(upiAmount = v) } },
                        label = { Text("Amount (INR)") },
                        placeholder = { Text("Optional") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("input_upi_amount")
                    )
                    OutlinedTextField(
                        value = formState.upiNote,
                        onValueChange = { v -> onUpdateForm { it.copy(upiNote = v) } },
                        label = { Text("Note") },
                        placeholder = { Text("Invoice #102") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            QrCategory.INSTAGRAM -> {
                OutlinedTextField(
                    value = formState.socialHandleOrUrl,
                    onValueChange = { v -> onUpdateForm { it.copy(socialHandleOrUrl = v) } },
                    label = { Text("Instagram Username or URL *") },
                    placeholder = { Text("@yourhandle or https://instagram.com/...") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_instagram")
                )
            }

            QrCategory.FACEBOOK -> {
                OutlinedTextField(
                    value = formState.socialHandleOrUrl,
                    onValueChange = { v -> onUpdateForm { it.copy(socialHandleOrUrl = v) } },
                    label = { Text("Facebook Page, Username, or URL *") },
                    placeholder = { Text("yourpage or https://facebook.com/...") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_facebook")
                )
            }

            QrCategory.YOUTUBE -> {
                OutlinedTextField(
                    value = formState.socialHandleOrUrl,
                    onValueChange = { v -> onUpdateForm { it.copy(socialHandleOrUrl = v) } },
                    label = { Text("YouTube Channel Handle or Video URL *") },
                    placeholder = { Text("@channel or https://youtube.com/watch?v=...") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("input_youtube")
                )
            }
        }
    }
}
