package com.example.ui.components

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ads.AdManager
import com.example.model.QrDesignConfig
import com.example.qr.QrBitmapRenderer
import com.example.qr.QrEncoder
import com.example.qr.QrExportFormat
import com.example.qr.QrFileHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QrExportActions(
    payload: String,
    title: String,
    designConfig: QrDesignConfig,
    onSaveToHistory: () -> Unit,
    onStatusMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    var isExporting by remember { mutableStateOf(false) }

    fun exportQr(format: QrExportFormat, label: String) {
        if (isExporting || payload.isBlank()) return
        scope.launch {
            isExporting = true
            val bitmap = withContext(Dispatchers.Default) {
                val matrix = QrEncoder.encode(payload) ?: return@withContext null
                QrBitmapRenderer.render(context, matrix, designConfig, outputSizePx = 1024)
            }
            if (bitmap == null) {
                onStatusMessage("Unable to render QR code.")
                isExporting = false
                return@launch
            }
            val result = QrFileHelper.saveToGallery(context, bitmap, title, format)
            if (!bitmap.isRecycled) bitmap.recycle()
            isExporting = false
            result.onSuccess { msg ->
                onStatusMessage("$label: $msg")
                AdManager.recordActionAndMaybeShowInterstitial(activity)
            }.onFailure { err ->
                onStatusMessage("Export failed: ${err.localizedMessage ?: "Storage error"}")
            }
        }
    }

    fun shareQr() {
        if (isExporting || payload.isBlank()) return
        scope.launch {
            isExporting = true
            val bitmap = withContext(Dispatchers.Default) {
                val matrix = QrEncoder.encode(payload) ?: return@withContext null
                QrBitmapRenderer.render(context, matrix, designConfig, outputSizePx = 1024)
            }
            if (bitmap == null) {
                onStatusMessage("Unable to render QR code for sharing.")
                isExporting = false
                return@launch
            }
            val result = QrFileHelper.shareQrBitmap(context, bitmap, title, QrExportFormat.PNG)
            if (!bitmap.isRecycled) bitmap.recycle()
            isExporting = false
            result.onSuccess { intent ->
                context.startActivity(intent)
                AdManager.recordActionAndMaybeShowInterstitial(activity)
            }.onFailure {
                onStatusMessage("Couldn't open share sheet.")
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { shareQr() },
                enabled = !isExporting && payload.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("share_qr_button")
            ) {
                Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Share QR")
            }

            FilledTonalButton(
                onClick = {
                    onSaveToHistory()
                    AdManager.recordActionAndMaybeShowInterstitial(activity)
                },
                enabled = payload.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("save_history_button")
            ) {
                Icon(Icons.Rounded.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Design")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ExportChipButton(
                label = "Download PNG",
                icon = Icons.Rounded.Download,
                enabled = !isExporting && payload.isNotBlank(),
                testTag = "download_png_button",
                onClick = { exportQr(QrExportFormat.PNG, "PNG Saved") }
            )
            ExportChipButton(
                label = "Download JPG",
                icon = Icons.Rounded.Image,
                enabled = !isExporting && payload.isNotBlank(),
                testTag = "download_jpg_button",
                onClick = { exportQr(QrExportFormat.JPG, "JPG Saved") }
            )
            ExportChipButton(
                label = "Save Gallery",
                icon = Icons.Rounded.PhotoLibrary,
                enabled = !isExporting && payload.isNotBlank(),
                testTag = "save_gallery_button",
                onClick = { exportQr(QrExportFormat.PNG, "Gallery") }
            )
            ExportChipButton(
                label = "Copy Content",
                icon = Icons.Rounded.ContentCopy,
                enabled = payload.isNotBlank(),
                testTag = "copy_content_button",
                onClick = {
                    QrFileHelper.copyToClipboard(context, title, payload)
                    onStatusMessage("QR content copied to clipboard")
                }
            )
        }
    }
}

@Composable
private fun ExportChipButton(
    label: String,
    icon: ImageVector,
    enabled: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        contentPadding = ButtonDefaults.ContentPadding,
        modifier = Modifier
            .height(48.dp)
            .testTag(testTag)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
