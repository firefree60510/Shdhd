package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.PayloadBuildResult
import com.example.model.QrCategory
import com.example.model.QrFormState
import com.example.model.QrPayloadBuilder
import com.example.model.QrTemplateRegistry
import com.example.model.WifiSecurity
import com.example.qr.QrBitmapRenderer
import com.example.qr.QrEncoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app_name matches QR Maker`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("QR Maker", appName)
    }

    @Test
    fun `all 14 categories encode valid scannable QR matrices`() {
        val sampleForms = listOf(
            QrFormState(category = QrCategory.URL, url = "qrmaker.app"),
            QrFormState(category = QrCategory.TEXT, text = "Hello QR Maker"),
            QrFormState(category = QrCategory.PHONE, phone = "+15551234567"),
            QrFormState(category = QrCategory.WHATSAPP, phone = "15551234567", message = "Hi!"),
            QrFormState(category = QrCategory.EMAIL, emailAddress = "hello@qrmaker.app", emailSubject = "Hi"),
            QrFormState(category = QrCategory.SMS, phone = "+15551234567", message = "Test SMS"),
            QrFormState(category = QrCategory.WIFI, wifiSsid = "StudioNet", wifiPassword = "secret", wifiSecurity = WifiSecurity.WPA),
            QrFormState(category = QrCategory.VCARD, firstName = "Alex", lastName = "Rivera", vcardPhone = "5551234"),
            QrFormState(category = QrCategory.LOCATION, latitude = "37.7749", longitude = "-122.4194", locationLabel = "SF"),
            QrFormState(category = QrCategory.UPI, upiId = "store@upi", upiPayeeName = "Store", upiAmount = "199"),
            QrFormState(category = QrCategory.INSTAGRAM, socialHandleOrUrl = "@qrmaker"),
            QrFormState(category = QrCategory.FACEBOOK, socialHandleOrUrl = "qrmaker"),
            QrFormState(category = QrCategory.YOUTUBE, socialHandleOrUrl = "@qrmaker"),
            QrFormState(category = QrCategory.CUSTOM, text = "{\"id\":42}")
        )

        assertEquals(QrCategory.entries.size, sampleForms.size)

        val context = ApplicationProvider.getApplicationContext<Context>()
        sampleForms.forEach { form ->
            val result = QrPayloadBuilder.build(form)
            assertTrue("Expected valid payload for ${form.category}", result is PayloadBuildResult.Valid)
            val valid = result as PayloadBuildResult.Valid
            val matrix = QrEncoder.encode(valid.payload)
            assertNotNull("Expected non-null matrix for ${form.category}", matrix)
            val bitmap = QrBitmapRenderer.render(context, matrix!!, QrTemplateRegistry.getById("classic").config, 256)
            assertEquals(256, bitmap.width)
            assertEquals(256, bitmap.height)
            bitmap.recycle()
        }
    }

    @Test
    fun `empty inputs fail validation cleanly`() {
        val emptyUrl = QrPayloadBuilder.build(QrFormState(category = QrCategory.URL, url = ""))
        assertTrue(emptyUrl is PayloadBuildResult.Invalid)

        val badUpi = QrPayloadBuilder.build(QrFormState(category = QrCategory.UPI, upiId = "invalid", upiPayeeName = "Test"))
        assertTrue(badUpi is PayloadBuildResult.Invalid)

        val badGeo = QrPayloadBuilder.build(QrFormState(category = QrCategory.LOCATION, latitude = "999", longitude = "0"))
        assertTrue(badGeo is PayloadBuildResult.Invalid)
    }

    @Test
    fun `template registry includes at least 20 templates with scannable contrast`() {
        val templates = QrTemplateRegistry.getAllTemplates()
        assertTrue("Expected >= 20 templates, found ${templates.size}", templates.size >= 20)

        val requiredNames = listOf(
            "Classic", "Gradient", "Neon", "Golden", "Blue",
            "Purple", "Red", "Green", "Rounded", "Dots",
            "Pixel", "Minimal", "Business", "Creative", "Premium",
            "Instagram", "WhatsApp", "Dark", "Colorful", "Modern"
        )
        val names = templates.map { it.name }.toSet()
        requiredNames.forEach { req ->
            assertTrue("Missing required template: $req", req in names)
        }

        templates.forEach { template ->
            val eval = QrEncoder.evaluateContrast(template.config)
            assertTrue("Template ${template.name} should have scannable contrast: ${eval.statusText}", eval.isScannable)
        }
    }

    @Test
    fun `low contrast config is flagged as not scannable`() {
        val lowContrast = QrTemplateRegistry.getById("classic").config.copy(
            foregroundColorArgb = 0xFFE2E8F0,
            backgroundColorArgb = 0xFFFFFFFF
        )
        val eval = QrEncoder.evaluateContrast(lowContrast)
        assertFalse(eval.isScannable)
    }
}
